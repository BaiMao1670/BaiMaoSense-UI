#pragma once
#include <d3d9.h>
#include <d3dx9tex.h>
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")

#include <unordered_map>

#include "Fonts/icons.h"
#include "Fonts/Segoui.hpp"
#include "logo.h"
#include "out_wpn.h"

// ImGui Power
#define IMGUI_DEFINE_MATH_OPERATORS

#include "../includes.hpp"

#include "../ImGui/imgui.h"
#include "../ImGui/imgui_internal.h"
#include "../ImGui/imgui_impl_dx9.h"
#include "../ImGui/imgui_impl_win32.h"

/*
#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_impl_dx9.h"
#include "imgui_impl_win32.h"
*/
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

template<class T>
constexpr const T& clamp(const T& v, const T& lo, const T& hi)
{
	return v < lo ? lo : hi < v ? hi : v;
}

// some paste
// https://gist.github.com/carasuca/e72aacadcf6cf8139de46f97158f790f
int rotation_start_index;
void ImRotateStart()
{
	rotation_start_index = ImGui::GetWindowDrawList()->VtxBuffer.Size;
}

ImVec2 ImRotationCenter()
{
	ImVec2 l(FLT_MAX, FLT_MAX), u(-FLT_MAX, -FLT_MAX); // bounds

	const auto& buf = ImGui::GetWindowDrawList()->VtxBuffer;
	for (int i = rotation_start_index; i < buf.Size; i++)
		l = ImMin(l, buf[i].pos), u = ImMax(u, buf[i].pos);

	return ImVec2((l.x + u.x) / 2, (l.y + u.y) / 2); // or use _ClipRectStack?
}

void ImRotateEnd(float rad, ImVec2 center = ImRotationCenter())
{
	float s = sin(rad), c = cos(rad);
	center = ImRotate(center, c, s) - center;

	auto& buf = ImGui::GetWindowDrawList()->VtxBuffer;
	for (int i = rotation_start_index; i < buf.Size; i++)
		buf[i].pos = ImRotate(buf[i].pos, c, s) - center;
}

namespace UI
{
	HWND m_hWindow = 0;
	IDirect3DDevice9* m_pDevice = nullptr;
	bool m_bHovered, m_bHold, m_bPressed;
	namespace Font
	{
		ImFont* m_pDefault;
		ImFont* m_pDefaultLarge;
		ImFont* m_pDefaultSmall;
		ImFont* m_pTitle;
		ImFont* m_pIcons;
		ImFont* m_pUserInfo;
		ImFont* m_pWpnIcon;

		void Init(ImGuiIO* m_pIO)
		{
			m_pDefault = m_pIO->Fonts->AddFontFromMemoryCompressedTTF(uSegoui, uSegouiSize, 18.f);
			m_pDefaultLarge = m_pIO->Fonts->AddFontFromMemoryCompressedTTF(uSegoui, uSegouiSize, 32.f);
			m_pDefaultSmall = m_pIO->Fonts->AddFontFromMemoryCompressedTTF(uSegoui, uSegouiSize, 12.f);
			m_pTitle = m_pIO->Fonts->AddFontFromMemoryCompressedTTF(uSegoui, uSegouiSize, 22.f);
			m_pIcons = m_pIO->Fonts->AddFontFromMemoryCompressedTTF(icons_compressed_data, icons_compressed_size, 16.f);
			m_pUserInfo = m_pDefault;//m_pIO->Fonts->AddFontFromFileTTF("C:/windows/fonts/simhei.ttf", 13.0f, 0, m_pIO->Fonts->GetGlyphRangesChineseFull());
			m_pWpnIcon = m_pIO->Fonts->AddFontFromMemoryCompressedTTF((void*)wpnfont, wpnfont_size, 18.f);
		}
	}

	void Init(HWND window, IDirect3DDevice9* device)
	{
		m_hWindow = window;
		m_pDevice = device;

		ImGui::CreateContext();
		ImGui_ImplWin32_Init(m_hWindow);
		ImGui_ImplDX9_Init(m_pDevice);
		Font::Init(&ImGui::GetIO());
	}


	/*
	*	Menu Part
	*/
	namespace Colors
	{
		ImU32 m_iText = IM_COL32(255, 255, 255, 255);
		ImU32 m_iTextAlt = IM_COL32(200, 200, 200, 255);
		ImU32 m_iMenuLeftBG = IM_COL32(36, 36, 36, 120);
		ImU32 m_iMenuBG = IM_COL32(24, 24, 24, 40);
		ImU32 m_iMenuAltBG = IM_COL32(36, 36, 36, 30);
		ImU32 m_iPopupBG = IM_COL32(45, 45, 45, 255);

		ImU32 m_iMenuShadow = IM_COL32(24, 24, 24, 100);

		ImU32 m_iItem0 = IM_COL32(123, 123, 123, 125);
	}

	namespace UniqueID
	{
		int m_iCurrent = 0;

		const char* Generate()
		{
			m_iCurrent++;
			int m_iSeed = 10000 + m_iCurrent * 8;

			return ("##Unique" + std::to_string(m_iSeed) + std::to_string(m_iCurrent)).c_str();
		}
		void Reset()
		{
			m_iCurrent = 0;
		}
	}

	namespace Fade
	{
		float m_fFramerate;
		
		namespace Internal
		{
			float m_iAlpha, m_iHoveredAlpha, m_fStep;
		}

		using AnimatedStruct = std::unordered_map<unsigned int, float>;

		std::pair<AnimatedStruct, AnimatedStruct> m_vAnimations;

		// Animation Processing

		void OnPreAnimation(unsigned int m_iID)
		{
			Internal::m_iAlpha = m_vAnimations.first[m_iID];
			Internal::m_iHoveredAlpha = m_vAnimations.second[m_iID];
			Internal::m_fStep = 2.f * (1000.f / m_fFramerate);
		}

		void OnPostAnimation(unsigned int m_iID, bool m_Toggled ,bool m_bIsHovered)
		{
			Internal::m_iHoveredAlpha = (m_bIsHovered ? Internal::m_iHoveredAlpha + Internal::m_fStep : Internal::m_iHoveredAlpha - Internal::m_fStep);
			Internal::m_iHoveredAlpha = clamp(Internal::m_iHoveredAlpha, 0.f, 255.f);
			m_vAnimations.second[m_iID] = Internal::m_iHoveredAlpha;

			Internal::m_iAlpha = (m_Toggled ? Internal::m_iAlpha + Internal::m_fStep : Internal::m_iAlpha - Internal::m_fStep);
			Internal::m_iAlpha = clamp(Internal::m_iAlpha, 0.f, 255.f);
			m_vAnimations.first[m_iID] = Internal::m_iAlpha;
		}

		void OnTabSwitch()
		{
			for (auto& i : m_vAnimations.first)
			{
				i.second = 0.f;
			}
			for (auto& i : m_vAnimations.second)
			{
				i.second = 0.f;
			}
		}

		void OnNewFrame()
		{
			m_fFramerate = ImGui::GetIO().Framerate;
		}
	}

	namespace Window
	{
		ImGuiWindow* m_pThis;
		ImDrawList* m_pDraw;

		ImVec2 m_iDrawPos;
		ImRect m_iRect;
	}
	
	namespace Render
	{
		void TransparentBoxes(ImDrawList* m_pDraw, ImRect m_iBB, float m_fSize = 4.f, float m_fRounding = 3.f)
		{
			static constexpr unsigned int m_uTransparentColor = IM_COL32(235, 235, 235, 255);
			static constexpr unsigned int m_uTransparentBoxColor = IM_COL32(200, 200, 200, 255);

			m_pDraw->AddRectFilled(m_iBB.Min, m_iBB.Max, m_uTransparentColor, m_fRounding);

			bool m_bSwitch = true;
			for (float m_fX = m_iBB.Min.x; m_iBB.Max.x >= m_fX; m_fX += m_fSize)
			{
				m_bSwitch = !m_bSwitch;
				int m_iCount = 1;
				for (float m_fY = m_iBB.Min.y; m_iBB.Max.y >= m_fY; m_fY += m_fSize)
				{
					if (static_cast<bool>(m_iCount % 2) == m_bSwitch)
					{
						ImRect m_iBox(ImVec2(m_fX, m_fY), ImVec2(m_fX + m_fSize, m_fY + m_fSize));
						if (m_iBox.Max.x > m_iBB.Max.x) m_iBox.Max.x = m_iBB.Max.x;
						else if (m_iBB.Min.x > m_iBox.Min.x) m_iBox.Min.x = m_iBB.Min.x;

						if (m_iBox.Max.y > m_iBB.Max.y) m_iBox.Max.y = m_iBB.Max.y;
						else if (m_iBB.Min.y > m_iBox.Min.y) m_iBox.Min.y = m_iBB.Min.y;

						m_pDraw->AddRectFilled(m_iBox.Min, m_iBox.Max, m_uTransparentBoxColor);
					}

					++m_iCount;
				}
			}
		}
	}

	namespace Groupbox
	{
		float m_fPositionHorizontal;
		float m_fPositionVertical[2];
		float m_fWidth = 0.f;
		
		// For each Items in Current Groubox
 		bool m_bRightSide = false;
		ImRect m_rGroupboxRect;

		void AddFull(float m_fHeight)
		{
			Window::m_iDrawPos.x = Groupbox::m_fPositionHorizontal;
			Window::m_iDrawPos.y = fmaxf(Groupbox::m_fPositionVertical[0], Groupbox::m_fPositionVertical[1]) + 10.f;


			Groupbox::m_fPositionVertical[0] += m_fHeight + 10.f;
			Groupbox::m_fPositionVertical[1] += m_fHeight + 10.f;

			float m_fWidth = Groupbox::m_fWidth * 2.f + 5.f;

			Window::m_iDrawPos += Window::m_pThis->Pos;

			m_rGroupboxRect = ImRect(Window::m_iDrawPos ,Window::m_iDrawPos + ImVec2(m_fWidth, m_fHeight));

			Window::m_pDraw->AddRectFilled(Window::m_iDrawPos, Window::m_iDrawPos + ImVec2(m_fWidth, m_fHeight), Colors::m_iMenuAltBG, 3.f);
		}

		bool Add(float m_fHeight, bool m_bSideRight = false)
		{
			m_bRightSide = m_bSideRight;

			m_fPositionVertical[m_bRightSide] += 10.f;

			Window::m_iDrawPos.x = m_fPositionHorizontal;
			if (m_bRightSide)
				Window::m_iDrawPos.x += m_fWidth + 5.f;

			Window::m_iDrawPos.y = m_fPositionVertical[m_bRightSide];
			m_fPositionVertical[m_bRightSide] += m_fHeight;

			Window::m_iDrawPos += Window::m_pThis->Pos;

			m_rGroupboxRect = ImRect(Window::m_iDrawPos, Window::m_iDrawPos + ImVec2(m_fWidth, m_fHeight));
			
			Window::m_pDraw->AddRectFilled(Window::m_iDrawPos, Window::m_iDrawPos + ImVec2(m_fWidth, m_fHeight), Colors::m_iMenuAltBG, 3.f);

			// Offset for items
			Window::m_iDrawPos += ImVec2(25.f, 15.f);

			return true;
		}
	}

	namespace Keybind
	{
		int* m_pValue = nullptr;

		char m_cKeyName[16] = { 0 };
		const char* m_cKeys[] =
		{
			0, 0, 0, 0, 0, 0, 0, 0, "Back", "Tab", 0, 0, "Clear", "Enter", 0, 0, "Shift", "CTRL", "ALT", 0, "Capital", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "Space", "PGUP", "PGDN", "End",
			"Home", "Left", "Up", "Right", "Down", "Select", 0, 0, 0, "Insert", "Delete", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "*", "+", ":", "-", ".", "/", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "=", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, " LShift", "RShift", "LCTRL", "RCTRL", "LALT", "RALT"
		};

		const char* GetName(int m_iValue)
		{
			if (m_iValue == 0)
			{
				sprintf_s(m_cKeyName, sizeof(m_cKeyName), "None");
				return m_cKeyName;
			}

			if (m_iValue >= VK_LBUTTON && VK_XBUTTON2 >= m_iValue)
			{
				int m_iMouseButton = m_iValue - VK_LBUTTON + 1;
				if (m_iMouseButton > 2) --m_iMouseButton;

				sprintf_s(m_cKeyName, sizeof(m_cKeyName), "M%i", m_iMouseButton);
				return m_cKeyName;
			}

			if (m_iValue >= VK_NUMPAD0 && VK_NUMPAD9 >= m_iValue) m_iValue = '0' + m_iValue - VK_NUMPAD0;

			if ((m_iValue >= '0' && '9' >= m_iValue) || (m_iValue >= 'A' && 'Z' >= m_iValue))
			{
				sprintf_s(m_cKeyName, sizeof(m_cKeyName), "%c", m_iValue);
				return m_cKeyName;
			}

			if (m_iValue >= VK_F1 && VK_F24 >= m_iValue)
			{
				sprintf_s(m_cKeyName, sizeof(m_cKeyName), "F%i", m_iValue - VK_F1 + 1);
				return m_cKeyName;
			}

			static constexpr int m_iKeysArraySize = sizeof(m_cKeys) / sizeof(m_cKeys[0]);
			if (m_iKeysArraySize > m_iValue) return m_cKeys[m_iValue];

			return nullptr;
		}
	}

	namespace ColorPicker
	{
		float m_fHSV[3];
		ImVec2 m_iCursorPosition;
	}

	namespace Helper
	{
		ImVec2 CalcTextSizeFont(ImFont* font,const char* text, const char* text_end = (char*)0, bool hide_text_after_double_hash = false, float wrap_width = -1.f)
		{
			ImGuiContext& g = *GImGui;

			const char* text_display_end;
			if (hide_text_after_double_hash)
				text_display_end = ImGui::FindRenderedTextEnd(text, text_end);      // Hide anything after a '##' string
			else
				text_display_end = text_end;

			const float font_size = g.FontSize;
			if (text == text_display_end)
				return ImVec2(0.0f, font_size);
			ImVec2 text_size = font->CalcTextSizeA(font_size, FLT_MAX, wrap_width, text, text_display_end, NULL);

			// Round
			text_size.x = IM_FLOOR(text_size.x + 0.95f);

			return text_size;
		}
		

	}

	namespace Item
	{
		unsigned int m_uID = 0U;
		char m_cID[16] = { 0 };
		const char* GetID()
		{
			sprintf_s(m_cID, sizeof(m_cID), "##%u", m_uID);
			++m_uID;
			return m_cID;
		}

		bool ButtonBehavior(ImRect m_iBB)
		{
			const ImGuiID m_iID = Window::m_pThis->GetID(GetID());
			
			if (ImGui::ItemAdd(m_iBB, m_iID)) m_bPressed = ImGui::ButtonBehavior(m_iBB, m_iID, &m_bHovered, &m_bHold);
			else m_bHovered = m_bHold = m_bPressed = false;

			return m_bPressed;
		}

		bool Button(std::string m_sName)
		{
			unsigned int m_iID = Window::m_pThis->GetID(UniqueID::Generate());
			Fade::OnPreAnimation(m_iID);

			ImRect m_iRect(Window::m_iDrawPos, Window::m_iDrawPos + ImVec2(Groupbox::m_fWidth - 50.f, 20.f));

			Window::m_pDraw->AddRectFilled(m_iRect.Min, m_iRect.Max, Colors::m_iItem0, 3.f);

			ImVec4 m_vColor = ImColor(Colors::m_iText);
			m_vColor.w = Fade::m_vAnimations.second[m_iID] / 255.f;

			Window::m_pDraw->AddRect(m_iRect.Min, m_iRect.Max, ImColor(m_vColor), 3.f);

			Window::m_pDraw->AddText(m_iRect.Min + ImVec2(10.f, 0.f), Colors::m_iText, m_sName.c_str());

			Window::m_iDrawPos.y += 30.f;

			bool m_IsPressed = ButtonBehavior(m_iRect);
			if (m_IsPressed)
			{
				ImVec4 m_vPressedColor = ImColor(Colors::m_iItem0);
				m_vPressedColor.w = 1.f;
				m_vPressedColor.x = (255.f - (m_vPressedColor.x * 255.f)) / 255.f;
				m_vPressedColor.y = (255.f - (m_vPressedColor.y * 255.f)) / 255.f;
				m_vPressedColor.z = (255.f - (m_vPressedColor.z * 255.f)) / 255.f;
				Window::m_pDraw->AddRectFilled(m_iRect.Min, m_iRect.Max, ImColor(m_vPressedColor), 3.f);
			}
			
			Fade::OnPostAnimation(m_iID, true, m_bHovered);

			return m_IsPressed;
		}

		void Text(std::string m_sString)
		{
			Window::m_pDraw->AddText(Window::m_iDrawPos, Colors::m_iText, m_sString.c_str());
			Window::m_iDrawPos.y += Font::m_pDefault->FontSize * 1.5f;
		}

		void Checkbox(std::string m_sName, bool* m_pBool)
		{
			// animation
			unsigned int m_ID = Window::m_pThis->GetID(UniqueID::Generate());
			Fade::OnPreAnimation(m_ID);
			
			// padding for 5.f
			Window::m_iDrawPos.y += 5.f;
		
			ImVec2 textSize = Helper::CalcTextSizeFont(Font::m_pDefault, m_sName.c_str());
			ImRect m_iRect(Window::m_iDrawPos, Window::m_iDrawPos + ImVec2(14.f, 14.f));

			ImRect m_rRange = ImRect(ImVec2(Groupbox::m_rGroupboxRect.Min.x, Window::m_iDrawPos.y) - ImVec2(0.f, 6.f), ImVec2(Groupbox::m_rGroupboxRect.Max.x, m_iRect.Max.y + 6));

			// checkbox border line
			Window::m_pDraw->AddRect(m_iRect.Min, m_iRect.Max, Colors::m_iItem0, 3.f);
			 
			if (ButtonBehavior(m_rRange))
				*m_pBool = !*m_pBool;

			// toggle & hovered update
			Fade::OnPostAnimation(m_ID, *m_pBool, m_bHovered);

			// hovered draw & animation
			ImVec4 m_vAnimatedColor1 = ImVec4(ImColor(Colors::m_iItem0));
			m_vAnimatedColor1.w = clamp(Fade::m_vAnimations.second[m_ID] / 255.f, 0.f, 0.3f);
			Window::m_pDraw->AddRectFilled(m_rRange.Min, m_rRange.Max, ImColor(m_vAnimatedColor1));

			// toggled draw
			ImVec4 m_vAnimatedColor = ImVec4(ImColor(Colors::m_iItem0));
			m_vAnimatedColor.w = Fade::m_vAnimations.first[m_ID] / 255.f;
			Window::m_pDraw->AddRectFilled(m_iRect.Min, m_iRect.Max, ImColor(m_vAnimatedColor), 3.f);

			Window::m_pDraw->AddText(Window::m_iDrawPos + ImVec2(20.f, Font::m_pDefault->FontSize * -0.15f), Colors::m_iText, m_sName.c_str());
			Window::m_iDrawPos.y += Font::m_pDefault->FontSize * 1.5f;
		}


		void ColorPicker(std::string m_sName, Color& m_pColor, bool m_bAlpha = false)
		{
			float m_fXOffset = Groupbox::m_fWidth - 50.f - 14.f;
			ImRect m_iRect(Window::m_iDrawPos, Window::m_iDrawPos + ImVec2(14.f, 14.f));
			m_iRect.Min.x += m_fXOffset;
			m_iRect.Max.x += m_fXOffset;

			if (m_sName.empty())
			{
				float m_fYOffset = Font::m_pDefault->FontSize * 1.5f;
				m_iRect.Min.y -= m_fYOffset;
				m_iRect.Max.y -= m_fYOffset;
			}
			else
				Window::m_pDraw->AddText(Window::m_iDrawPos + ImVec2(0.f, Font::m_pDefault->FontSize * -0.175f), Colors::m_iText, m_sName.c_str());
			
			float r, g, b, a;
			int ir, ig, ib, ia;
			m_pColor.GetColor(ir, ig, ib, ia);
			r = ir / 255.f;
			g = ig / 255.f;
			b = ib / 255.f;
			a = ia / 255.f;

			ImVec4 m_iColor = ImVec4(r, g, b, m_bAlpha ? a : 1.f);

			if (m_bAlpha) Render::TransparentBoxes(Window::m_pDraw, m_iRect, 2.f, 3.f);
			Window::m_pDraw->AddRectFilled(m_iRect.Min, m_iRect.Max, ImGui::ColorConvertFloat4ToU32(m_iColor), 3.f);

			for (float f = 0.f; 2.f > f; f += 0.5f)
				Window::m_pDraw->AddRect(m_iRect.Min - ImVec2(f, f), m_iRect.Max + ImVec2(f, f), Colors::m_iMenuAltBG, 3.f);

			Window::m_pDraw->AddRect(m_iRect.Min, m_iRect.Max, Colors::m_iItem0, 3.f);

			const char* m_pColorPickerID = GetID();
			const ImGuiID m_iColorPicker = Window::m_pThis->GetID(m_pColorPickerID);
			bool m_bColorPickerOpen = ImGui::IsPopupOpen(m_iColorPicker, ImGuiPopupFlags_None);
			if (m_bColorPickerOpen)
			{
				ImGui::SetNextWindowPos(ImVec2(m_iRect.Max.x + 10.f, m_iRect.Min.y));
				ImGui::SetNextWindowSize(ImVec2(m_bAlpha ? 272.f : 242.f, 207.f));

				if (ImGui::Begin(m_pColorPickerID, nullptr, ImGuiWindowFlags_Popup | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove))
				{
					ImGuiWindow* m_pColorPicker = ImGui::GetCurrentWindow();
					ImDrawList* m_pColorPickerDraw = m_pColorPicker->DrawList;

					m_pColorPickerDraw->AddRectFilled(m_pColorPicker->InnerClipRect.Min, m_pColorPicker->InnerClipRect.Max, Colors::m_iPopupBG, 3.f);

					// SV Rectangle
					ImVec4 m_vHueColor; m_vHueColor.w = 1.f;
					ImGui::ColorConvertHSVtoRGB(ColorPicker::m_fHSV[0], 1.f, 1.f, m_vHueColor.x, m_vHueColor.y, m_vHueColor.z);
					ImU32 m_uHueColor = ImGui::ColorConvertFloat4ToU32(m_vHueColor);
					ImRect m_iSV(ImVec2(m_pColorPicker->InnerClipRect.Min.x + 15.f, m_pColorPicker->InnerClipRect.Min.y + 15.f), ImVec2(m_pColorPicker->InnerClipRect.Min.x + 190.f, m_pColorPicker->InnerClipRect.Min.y + 190.f));
					m_pColorPickerDraw->AddRectFilledMultiColor(m_iSV.Min, m_iSV.Max, IM_COL32_WHITE, m_uHueColor, m_uHueColor, IM_COL32_WHITE);
					m_pColorPickerDraw->AddRectFilledMultiColor(m_iSV.Min, m_iSV.Max, 0, 0, IM_COL32_BLACK, IM_COL32_BLACK);

					if (ButtonBehavior(m_iSV) || m_bHold)
					{
						ColorPicker::m_iCursorPosition = ImGui::GetMousePos();

						if (ColorPicker::m_iCursorPosition.x > m_iSV.Max.x) ColorPicker::m_iCursorPosition.x = m_iSV.Max.x;
						else if (m_iSV.Min.x > ColorPicker::m_iCursorPosition.x) ColorPicker::m_iCursorPosition.x = m_iSV.Min.x;

						if (ColorPicker::m_iCursorPosition.y > m_iSV.Max.y) ColorPicker::m_iCursorPosition.y = m_iSV.Max.y;
						else if (m_iSV.Min.y > ColorPicker::m_iCursorPosition.y) ColorPicker::m_iCursorPosition.y = m_iSV.Min.y;

						ColorPicker::m_fHSV[2] = 1.f - ((ColorPicker::m_iCursorPosition.y - m_iSV.Min.y) / (m_iSV.Max.y - m_iSV.Min.y));
						ColorPicker::m_fHSV[1] = (ColorPicker::m_iCursorPosition.x - m_iSV.Min.x) / (m_iSV.Max.x - m_iSV.Min.x);

						ImGui::ColorConvertHSVtoRGB(ColorPicker::m_fHSV[0], ColorPicker::m_fHSV[1], ColorPicker::m_fHSV[2], r, g, b);
					}

					// SV Cursor
					if (ColorPicker::m_iCursorPosition.x == -1.f)
					{
						ColorPicker::m_iCursorPosition.x = m_iSV.Min.x + ((m_iSV.Max.x - m_iSV.Min.x) * ColorPicker::m_fHSV[1]);
						ColorPicker::m_iCursorPosition.y = m_iSV.Min.y + ((m_iSV.Max.y - m_iSV.Min.y) * (1.f - ColorPicker::m_fHSV[2]));
					}
					m_pColorPickerDraw->AddCircleFilled(ColorPicker::m_iCursorPosition, 8.f, Colors::m_iText, IM_DRAWLIST_CIRCLE_AUTO_SEGMENT_MAX);

					// Hue
					const ImU32 m_uHues[] = { IM_COL32(255, 0, 0, 255), IM_COL32(255, 255, 0, 255), IM_COL32(0, 255 ,0, 255), IM_COL32(0, 255, 255, 255), IM_COL32(0, 0, 255, 255), IM_COL32(255, 0, 255, 255), IM_COL32(255, 0, 0, 255) };
					ImRect m_iHue(ImVec2(m_iSV.Max.x + 10.f, m_iSV.Min.y), ImVec2(m_iSV.Max.x + 30.f, m_iSV.Max.y));
					const float m_fHueHeight = (m_iHue.Max.y - m_iHue.Min.y) / 6.f;
					for (int i = 0; 6 > i; ++i) m_pColorPickerDraw->AddRectFilledMultiColor(ImVec2(m_iHue.Min.x, m_iHue.Min.y + i * m_fHueHeight), ImVec2(m_iHue.Max.x, m_iHue.Min.y + (i + 1) * m_fHueHeight), m_uHues[i], m_uHues[i], m_uHues[i + 1], m_uHues[i + 1]);

					// Hue Holder
					float m_fHuePosition = m_iHue.Min.y + ((m_iHue.Max.y - m_iHue.Min.y) * ColorPicker::m_fHSV[0]);
					m_pColorPickerDraw->AddCircle(ImVec2(m_iHue.Min.x + ((m_iHue.Max.x - m_iHue.Min.x) * 0.5f), m_fHuePosition), 8.f, Colors::m_iText, IM_DRAWLIST_CIRCLE_AUTO_SEGMENT_MAX, 2.f);

					if (ButtonBehavior(m_iHue) || m_bHold)
					{
						ImVec2 m_iHuePosition = ImGui::GetMousePos();

						ColorPicker::m_fHSV[0] = (m_iHuePosition.y - m_iHue.Min.y) / (m_iHue.Max.y - m_iHue.Min.y);
						if (ColorPicker::m_fHSV[0] > 1.f) ColorPicker::m_fHSV[0] = 1.f;
						else if (0.f > ColorPicker::m_fHSV[0]) ColorPicker::m_fHSV[0] = 0.f;

						ImGui::ColorConvertHSVtoRGB(ColorPicker::m_fHSV[0], ColorPicker::m_fHSV[1], ColorPicker::m_fHSV[2], r, g, b);
					}

					if (m_bAlpha)
					{
						ImRect m_iAlpha(ImVec2(m_iHue.Max.x + 10.f, m_iHue.Min.y), ImVec2(m_iHue.Max.x + 30.f, m_iHue.Max.y));
						Render::TransparentBoxes(m_pColorPickerDraw, m_iAlpha, 5.f, 0.f);
						m_pColorPickerDraw->AddRectFilledMultiColor(m_iAlpha.Min, m_iAlpha.Max, m_uHueColor, m_uHueColor, 0, 0);

						// Holder
						float m_fAlphaPosition = m_iAlpha.Min.y + ((m_iAlpha.Max.y - m_iAlpha.Min.y) * (1.f - a));
						m_pColorPickerDraw->AddCircle(ImVec2(m_iAlpha.Min.x + ((m_iAlpha.Max.x - m_iAlpha.Min.x) * 0.5f), m_fAlphaPosition), 8.f, Colors::m_iText, IM_DRAWLIST_CIRCLE_AUTO_SEGMENT_MAX, 2.f);
					
						if (ButtonBehavior(m_iAlpha) || m_bHold)
						{
							ImVec2 m_hAlphaPosition = ImGui::GetMousePos();

							a = 1.f - (m_hAlphaPosition.y - m_iAlpha.Min.y) / (m_iAlpha.Max.y - m_iAlpha.Min.y);
							if (a > 1.f) a = 1.f;
							else if (0.f > a) a = 0.f;
						}
					}

					ImGui::End();
				}
			}
			else if (ButtonBehavior(m_iRect))
			{
				ImGui::OpenPopupEx(m_iColorPicker, ImGuiPopupFlags_None);
				ImGui::ColorConvertRGBtoHSV(m_pColor[0], m_pColor[1], m_pColor[2], ColorPicker::m_fHSV[0], ColorPicker::m_fHSV[1], ColorPicker::m_fHSV[2]);
				ColorPicker::m_iCursorPosition.x = ColorPicker::m_iCursorPosition.y = -1.f;
			}

			if (!m_sName.empty())
				Window::m_iDrawPos.y += Font::m_pDefault->FontSize;
			
			m_pColor = Color(r, g, b, a);
		}

		void ColorPicker(std::string m_sName, ImVec4& m_pColor, bool m_bAlpha = false)
		{
			Color col = Color(m_pColor.x, m_pColor.y, m_pColor.z, m_pColor.w);
			ColorPicker(m_sName, col, m_bAlpha);
			int r, g, b, a;
			col.GetColor(r, g, b, a);
			m_pColor = ImVec4(r / 255.f , g / 255.f, b / 255.f, a / 255.f);
		}
		void ColorPicker(std::string m_sName, ImU32& m_pColor, bool m_bAlpha = false)
		{
			ImVec4 vec4_col = ImGui::ColorConvertU32ToFloat4(m_pColor);
			Color col = Color(vec4_col.x, vec4_col.y, vec4_col.z, vec4_col.w);
			ColorPicker(m_sName, col, m_bAlpha);
			int r, g, b, a;
			col.GetColor(r, g, b, a);
			
			m_pColor = ImGui::ColorConvertFloat4ToU32(ImVec4(r / 255.f, g / 255.f, b / 255.f, a / 255.f));
		}

		void Combo(std::string m_sName, int* m_pValue, std::string* m_pList, size_t m_sLength, bool Chinese = false)
		{
			Window::m_pDraw->AddText(Window::m_iDrawPos, Colors::m_iText, m_sName.c_str());
			Window::m_iDrawPos.y += Font::m_pDefault->FontSize * 1.5f;

			ImRect m_iRect(Window::m_iDrawPos, Window::m_iDrawPos + ImVec2(Groupbox::m_fWidth - 50.f, 24.f));
			
			Window::m_pDraw->AddRectFilled(m_iRect.Min, m_iRect.Max, Colors::m_iItem0, 3.f);

			ImVec2 m_iArrowDown(m_iRect.Max.x - 16.f, m_iRect.Min.y + ((m_iRect.Max.y - m_iRect.Min.y) * 0.5f) + 2.f);
			Window::m_pDraw->AddLine(m_iArrowDown + ImVec2(-4.f, -4.f), m_iArrowDown, Colors::m_iText, 1.f);
			Window::m_pDraw->AddLine(m_iArrowDown + ImVec2(4.f, -4.f), m_iArrowDown, Colors::m_iText, 1.f);
			if (*m_pValue > m_sLength)
			{
				*m_pValue = 0;
			}
			if (Chinese)
			{
				Window::m_pDraw->AddText(Font::m_pUserInfo, Font::m_pDefault->FontSize, ImVec2(m_iRect.Min.x + 10.f, m_iRect.Min.y + 2.f), Colors::m_iText, m_pList[*m_pValue].c_str());
			}
			else
			{
				Window::m_pDraw->AddText(ImVec2(m_iRect.Min.x + 10.f, m_iRect.Min.y + 2.f), Colors::m_iText, m_pList[*m_pValue].c_str());
			}

			const char* m_pComboID = GetID();
			const ImGuiID m_iCombo = Window::m_pThis->GetID(m_pComboID);
			bool m_bComboOpen = ImGui::IsPopupOpen(m_iCombo, ImGuiPopupFlags_None);
			if (ButtonBehavior(m_iRect) && !m_bComboOpen)
			{
				ImGui::OpenPopupEx(m_iCombo, ImGuiPopupFlags_None);
				m_bComboOpen = true;
			}

			if (m_bComboOpen)
			{
				float m_fComboSize = (Font::m_pDefault->FontSize + 5.f) * fminf(8.f, static_cast<float>(m_sLength));

				ImGui::SetNextWindowPos(ImVec2(m_iRect.Min.x - 4.f, m_iRect.Max.y));
				ImGui::SetNextWindowSize(ImVec2(Groupbox::m_fWidth - 41.f, m_fComboSize));

				if (ImGui::Begin(m_pComboID, nullptr, ImGuiWindowFlags_Popup | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove))
				{
					ImGuiWindow* m_pCombo = ImGui::GetCurrentWindow();
					ImDrawList* m_pComboDraw = m_pCombo->DrawList;
					ImVec2 m_iComboDrawPos = m_pCombo->DC.CursorPos;

					m_pComboDraw->AddRectFilled(m_pCombo->InnerClipRect.Min, m_pCombo->InnerClipRect.Max, Colors::m_iPopupBG);

					for (int i = 0; static_cast<int>(m_sLength) > i; ++i)
					{
						const char* m_pItemText = &m_pList[i][0];

						ImRect m_iBBItem(ImVec2(m_iComboDrawPos.x, m_iComboDrawPos.y - 5.f), ImVec2(m_iComboDrawPos.x + m_pCombo->Size.x, m_iComboDrawPos.y - 5.f + Font::m_pDefault->FontSize));
						if (ButtonBehavior(m_iBBItem))
						{
							*m_pValue = i;
							ImGui::CloseCurrentPopup();
						}

						if (Chinese)
						{
							m_pComboDraw->AddText(Font::m_pUserInfo, Font::m_pDefault->FontSize,ImVec2(m_iComboDrawPos.x + 10.f, m_iComboDrawPos.y - 5.f), Colors::m_iText, m_pItemText);
							if (i == *m_pValue)
								m_pComboDraw->AddText(Font::m_pUserInfo, Font::m_pDefault->FontSize, ImVec2(m_iComboDrawPos.x + 11.f, m_iComboDrawPos.y - 5.f), Colors::m_iText, m_pItemText);
						}
						else
						{
							m_pComboDraw->AddText(ImVec2(m_iComboDrawPos.x + 10.f, m_iComboDrawPos.y - 5.f), Colors::m_iText, m_pItemText);
							if (i == *m_pValue)
								m_pComboDraw->AddText(ImVec2(m_iComboDrawPos.x + 11.f, m_iComboDrawPos.y - 5.f), Colors::m_iText, m_pItemText);
						}

						m_iComboDrawPos.y += Font::m_pDefault->FontSize + 5.f;
					}

					m_pCombo->DC.CursorPos.y = m_pCombo->DC.CursorMaxPos.y = m_iComboDrawPos.y - 8.f;

					ImGui::End();
				}
			}

			Window::m_iDrawPos.y += 40.f;
		}

		void ComboMulti(std::string m_sName, int* m_pValue, std::string* m_pList, size_t m_sLength, std::string m_sEmpty = "")
		{
			Window::m_pDraw->AddText(Window::m_iDrawPos, Colors::m_iText, m_sName.c_str());
			Window::m_iDrawPos.y += Font::m_pDefault->FontSize * 1.5f;

			ImRect m_iRect(Window::m_iDrawPos, Window::m_iDrawPos + ImVec2(Groupbox::m_fWidth - 50.f, 24.f));

			Window::m_pDraw->AddRectFilled(m_iRect.Min, m_iRect.Max, Colors::m_iItem0, 3.f);

			ImVec2 m_iArrowDown(m_iRect.Max.x - 16.f, m_iRect.Min.y + ((m_iRect.Max.y - m_iRect.Min.y) * 0.5f) + 2.f);
			Window::m_pDraw->AddLine(m_iArrowDown + ImVec2(-4.f, -4.f), m_iArrowDown, Colors::m_iText, 1.f);
			Window::m_pDraw->AddLine(m_iArrowDown + ImVec2(4.f, -4.f), m_iArrowDown, Colors::m_iText, 1.f);

			std::string m_sPreview;
			for (int i = 0; static_cast<int>(m_sLength) > i; ++i)
			{
				if (*m_pValue & (1 << i))
				{
					std::string m_sTempPreview = m_sPreview + m_pList[i];
					float m_fWidthPreview = Font::m_pDefault->CalcTextSizeA(Font::m_pDefault->FontSize, FLT_MAX, 0.f, m_sTempPreview.c_str()).x;
					if (m_iRect.Min.x + m_fWidthPreview >= m_iArrowDown.x - 20.f)
					{
						m_sPreview += ", ...";
						break;
					}

					if (!m_sPreview.empty())
						m_sPreview += ", ";

					m_sPreview += m_pList[i];
				}
			}
			if (m_sPreview.empty())
				m_sPreview = m_sEmpty;

			Window::m_pDraw->AddText(ImVec2(m_iRect.Min.x + 10.f, m_iRect.Min.y + 2.f), Colors::m_iText, m_sPreview.c_str());

			const char* m_pComboID = GetID();
			const ImGuiID m_iCombo = Window::m_pThis->GetID(m_pComboID);
			bool m_bComboOpen = ImGui::IsPopupOpen(m_iCombo, ImGuiPopupFlags_None);
			if (ButtonBehavior(m_iRect) && !m_bComboOpen)
			{
				ImGui::OpenPopupEx(m_iCombo, ImGuiPopupFlags_None);
				m_bComboOpen = true;
			}

			if (m_bComboOpen)
			{
				float m_fComboSize = (Font::m_pDefault->FontSize + 5.f) * fminf(8.f, static_cast<float>(m_sLength));

				ImGui::SetNextWindowPos(ImVec2(m_iRect.Min.x - 4.f, m_iRect.Max.y));
				ImGui::SetNextWindowSize(ImVec2(Groupbox::m_fWidth - 41.f, m_fComboSize));

				if (ImGui::Begin(m_pComboID, nullptr, ImGuiWindowFlags_Popup | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove))
				{
					ImGuiWindow* m_pCombo = ImGui::GetCurrentWindow();
					ImDrawList* m_pComboDraw = m_pCombo->DrawList;
					ImVec2 m_iComboDrawPos = m_pCombo->DC.CursorPos;

					m_pComboDraw->AddRectFilled(m_pCombo->InnerClipRect.Min, m_pCombo->InnerClipRect.Max, Colors::m_iPopupBG);

					for (int i = 0; static_cast<int>(m_sLength) > i; ++i)
					{
						bool m_bSelected = *m_pValue & (1 << i);

						const char* m_pItemText = &m_pList[i][0];

						ImRect m_iBBItem(ImVec2(m_iComboDrawPos.x, m_iComboDrawPos.y - 5.f), ImVec2(m_iComboDrawPos.x + m_pCombo->Size.x, m_iComboDrawPos.y - 5.f + Font::m_pDefault->FontSize));
						if (ButtonBehavior(m_iBBItem))
						{
							if (m_bSelected) *m_pValue &= ~(1 << i);
							else *m_pValue |= 1 << i;
						}

						m_pComboDraw->AddText(ImVec2(m_iComboDrawPos.x + 10.f, m_iComboDrawPos.y - 5.f), Colors::m_iText, m_pItemText);
						if (m_bSelected)
							m_pComboDraw->AddText(ImVec2(m_iComboDrawPos.x + 11.f, m_iComboDrawPos.y - 5.f), Colors::m_iText, m_pItemText);

						m_iComboDrawPos.y += Font::m_pDefault->FontSize + 5.f;
					}

					m_pCombo->DC.CursorPos.y = m_pCombo->DC.CursorMaxPos.y = m_iComboDrawPos.y - 8.f;

					ImGui::End();
				}
			}

			Window::m_iDrawPos.y += 30.f;
		}

		void Listbox(std::string m_sName, int* m_pValue, std::string* m_pList, size_t m_sLength, float m_fWidth = 50.f)
		{
			if (!m_sName.empty())
			{
				Window::m_pDraw->AddText(Window::m_iDrawPos, Colors::m_iText, m_sName.c_str());
				Window::m_iDrawPos.y += Font::m_pDefault->FontSize * 1.5f;
			}

			ImVec2 m_iSize(Groupbox::m_fWidth - 50.f, m_fWidth);

			Window::m_pDraw->AddRectFilled(Window::m_iDrawPos, Window::m_iDrawPos + m_iSize, Colors::m_iPopupBG, 3.f);

			ImGui::SetCursorPos(Window::m_iDrawPos - Window::m_pThis->Pos + ImVec2(0.f, Window::m_pThis->Scroll.y));
			ImGui::BeginGroup();
			if (ImGui::BeginChildFrame(Window::m_pThis->GetID(GetID()), m_iSize, ImGuiWindowFlags_NoBackground))
			{
				ImGuiWindow* m_pChild = ImGui::GetCurrentWindow();

				ImDrawList* m_pChildDraw = m_pChild->DrawList;
				ImVec2 m_iChildDrawPos = m_pChild->DC.CursorPos;
				m_iChildDrawPos.y += 5.f;

				for (int i = 0; static_cast<int>(m_sLength) > i; ++i)
				{
					const char* m_pItemText = &m_pList[i][0];

					ImRect m_iBBItem(ImVec2(m_pChild->Pos.x, m_iChildDrawPos.y - 5.f), ImVec2(m_pChild->Pos.x + m_pChild->Size.x, m_iChildDrawPos.y - 5.f + Font::m_pDefault->FontSize));
					if (ButtonBehavior(m_iBBItem))
					{
						*m_pValue = i;
					}

					m_pChildDraw->AddText(ImVec2(m_iChildDrawPos.x + 5.f, m_iChildDrawPos.y - 5.f), Colors::m_iText, m_pItemText);
					if (*m_pValue == i)
						m_pChildDraw->AddText(ImVec2(m_iChildDrawPos.x + 6.f, m_iChildDrawPos.y - 5.f), Colors::m_iText, m_pItemText);

					m_iChildDrawPos.y += Font::m_pDefault->FontSize + 5.f;
				}
				m_pChild->DC.CursorPos.y = m_pChild->DC.CursorMaxPos.y = m_iChildDrawPos.y - 8.f;

			}
			ImGui::EndChildFrame();
			ImGui::EndGroup();

			Window::m_iDrawPos.y += m_fWidth + 10.f;
		}
		
		void Keybind(std::string m_sName, int* m_pKey, int* m_pType = nullptr)
		{
			int vk_key = m_inputsys()->ButtonCodeToVirtualKey((ButtonCode_t)*m_pKey);

			Window::m_pDraw->AddText(Window::m_iDrawPos, Colors::m_iText, m_sName.c_str());

			Window::m_iDrawPos.y += 4.f;
			ImRect m_iRect(Window::m_iDrawPos, Window::m_iDrawPos + ImVec2(Groupbox::m_fWidth - 50.f, 15.f));
			m_iRect.Min.x += (m_iRect.Max.x - m_iRect.Min.x) * 0.75f;

			Window::m_pDraw->AddRectFilled(m_iRect.Min, m_iRect.Max, Colors::m_iItem0, 3.f);
			
			std::string m_sKeyName = Keybind::GetName(vk_key);
			switch (*m_pKey)
			{
			case MOUSE_LEFT:
				m_sKeyName = "MOUSE1";
				break;
			case MOUSE_RIGHT:
				m_sKeyName = "MOUSE2";
				break;
			case MOUSE_4:
				m_sKeyName = "MOUSE4";
				break;
			case MOUSE_5:
				m_sKeyName = "MOUSE5";
				break;
			case MOUSE_MIDDLE:
				m_sKeyName = "MOUSE3";
				break;
			case KEY_LSHIFT:
				m_sKeyName = "LSHIFT";
				break;
			case KEY_LCONTROL:
				m_sKeyName = "LCTRL";
				break;
			case KEY_LALT:
				m_sKeyName = "LALT";
				break;
			case KEY_RSHIFT:
				m_sKeyName = "RSHIFT";
				break;
			case KEY_RCONTROL:
				m_sKeyName = "RCTRL";
				break;
			case KEY_RALT:
				m_sKeyName = "RALT";
				break;
			}
			if (ButtonBehavior(m_iRect) || Keybind::m_pValue == &vk_key)
			{
				Keybind::m_pValue = m_pKey;
				m_sKeyName = "-";
			}
			else if (m_pType)
			{
				const char* m_pComboID = GetID();
				const ImGuiID m_iCombo = Window::m_pThis->GetID(m_pComboID);
				bool m_bComboOpen = ImGui::IsPopupOpen(m_iCombo, ImGuiPopupFlags_None);
				if (m_bHovered && ImGui::GetIO().MouseClicked[1] && !m_bComboOpen)
				{
					ImGui::OpenPopupEx(m_iCombo, ImGuiPopupFlags_None);
					m_bComboOpen = true;
				}

				if (m_bComboOpen)
				{
					ImGui::SetNextWindowPos(ImVec2(m_iRect.Min.x - 3.f, m_iRect.Max.y + 5.f));
					ImGui::SetNextWindowSize(ImVec2(m_iRect.Max.x - m_iRect.Min.x + 8.f, (Font::m_pDefault->FontSize + 5.f) * 3.f));

					if (ImGui::Begin(m_pComboID, nullptr, ImGuiWindowFlags_Popup | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove))
					{
						ImGuiWindow* m_pCombo = ImGui::GetCurrentWindow();
						ImDrawList* m_pComboDraw = m_pCombo->DrawList;
						ImVec2 m_iComboDrawPos = m_pCombo->DC.CursorPos;
						m_iComboDrawPos.x -= 8.f;

						m_pComboDraw->AddRectFilled(m_pCombo->InnerClipRect.Min, m_pCombo->InnerClipRect.Max, Colors::m_iItem0, 3.f);

						const char* m_pKeyTypes[] = { "Hold", "Toggle", "Always" };
						for (int i = 0; 3 > i; ++i)
						{
							ImRect m_iBBItem(ImVec2(m_iComboDrawPos.x, m_iComboDrawPos.y - 5.f), ImVec2(m_iComboDrawPos.x + m_pCombo->Size.x, m_iComboDrawPos.y - 5.f + Font::m_pDefault->FontSize));
							if (ButtonBehavior(m_iBBItem))
							{
								*m_pType = i;
								ImGui::CloseCurrentPopup();
							}

							const char* m_pItemText = m_pKeyTypes[i];
							m_pComboDraw->AddText(ImVec2(m_iComboDrawPos.x + 10.f, m_iComboDrawPos.y - 5.f), Colors::m_iText, m_pItemText);
							if (*m_pType == i)
								m_pComboDraw->AddText(ImVec2(m_iComboDrawPos.x + 11.f, m_iComboDrawPos.y - 5.f), Colors::m_iText, m_pItemText);
							
							m_iComboDrawPos.y += Font::m_pDefault->FontSize + 5.f;
						}

						ImGui::End();
					}
				}
			}

			ImVec2 m_iNameSize = Font::m_pDefault->CalcTextSizeA(Font::m_pDefault->FontSize, FLT_MAX, 0.f, m_sKeyName.c_str());
			Window::m_pDraw->AddText(ImVec2(m_iRect.Min.x + ((m_iRect.Max.x - m_iRect.Min.x) * 0.5f) - (m_iNameSize.x * 0.5f), m_iRect.Min.y + ((m_iRect.Max.y - m_iRect.Min.y) * 0.5f) - (m_iNameSize.y * 0.5f)), Colors::m_iText, m_sKeyName.c_str());

			Window::m_iDrawPos.y += 30.f;
		}

		void InputText(std::string m_sName, char* m_pData, size_t m_sLength, ImGuiInputTextFlags m_iFlags = 0)
		{
			if (!m_sName.empty())
			{
				Window::m_pDraw->AddText(Window::m_iDrawPos, Colors::m_iText, m_sName.c_str());
				Window::m_iDrawPos.y += Font::m_pDefault->FontSize * 1.5f;
			}

			ImVec2 m_iSize(Groupbox::m_fWidth - 50.f, 24.f);
			Window::m_pDraw->AddRectFilled(Window::m_iDrawPos, Window::m_iDrawPos + m_iSize, Colors::m_iPopupBG, 3.f);

			ImGui::SetCursorPos(Window::m_iDrawPos + ImVec2(2.f, Window::m_pThis->Scroll.y) - Window::m_pThis->Pos);
			ImGui::SetNextItemWidth(m_iSize.x - 4.f);

			ImGui::PushStyleColor(ImGuiCol_Text, Colors::m_iText);
			ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4());
			ImGui::PushStyleColor(ImGuiCol_TextSelectedBg, ImVec4());
			ImGui::InputText(Item::GetID(), m_pData, m_sLength, m_iFlags);
			ImGui::PopStyleColor(3);

			Window::m_iDrawPos.y += m_iSize.y + 10.f;
		}

		float SliderHandle(const char* m_pName, float m_fMin, float m_fMax, float m_fValue, int m_iDecimal = 0)
		{
			Window::m_pDraw->AddText(Window::m_iDrawPos + ImVec2(2.f, 0.f), Colors::m_iText, m_pName);

			unsigned int m_iID = Window::m_pThis->GetID(UniqueID::Generate());
			Fade::OnPreAnimation(m_iID);

			std::string m_sValueString;
			if (m_iDecimal > 0)
			{
				m_sValueString = "%." + std::to_string(m_iDecimal) + "f";

				char m_cTemp[32];
				sprintf_s(m_cTemp, sizeof(m_cTemp), &m_sValueString[0], m_fValue);

				m_sValueString = m_cTemp;
			}
			else m_sValueString = std::to_string(static_cast<int>(m_fValue));

			float m_fValueWidth = Font::m_pDefaultSmall->CalcTextSizeA(Font::m_pDefaultSmall->FontSize, FLT_MAX, 0.f, m_sValueString.c_str()).x;
			Window::m_pDraw->AddText(Font::m_pDefaultSmall, Font::m_pDefaultSmall->FontSize, Window::m_iDrawPos + ImVec2(Groupbox::m_fWidth - 52.f - m_fValueWidth, 5.f), Colors::m_iText, m_sValueString.c_str());

			Window::m_iDrawPos.y += Font::m_pDefault->FontSize * 1.5f;

			ImRect m_iRect(Window::m_iDrawPos, Window::m_iDrawPos + ImVec2(Groupbox::m_fWidth - 50.f, 4.f));
			ButtonBehavior(ImRect(m_iRect.Min - ImVec2(0.f, 5.f), m_iRect.Max + ImVec2(0.f, 5.f)));

			Fade::OnPostAnimation(m_iID, true, true);

			float m_fPercentage = ((m_fValue - m_fMin) / (m_fMax - m_fMin)) * (Fade::m_vAnimations.first[m_iID] / 255.f);
			float m_fWidth = fmaxf(1.f, (m_iRect.Max.x - m_iRect.Min.x) * m_fPercentage);

			if (m_bHold)
			{
				float m_fValuePercentage = (ImGui::GetMousePos().x - m_iRect.Min.x) / (m_iRect.Max.x - m_iRect.Min.x);
				m_fValue = ((m_fMax - m_fMin) * m_fValuePercentage) + m_fMin;
				if (m_fValue > m_fMax) m_fValue = m_fMax;
				else if (m_fMin > m_fValue) m_fValue = m_fMin;
			
				m_iRect.Min.y -= 1;
				m_iRect.Max.y += 1;
			}

			Window::m_pDraw->AddRectFilled(m_iRect.Min, m_iRect.Max, Colors::m_iItem0);
			Window::m_pDraw->AddRectFilled(m_iRect.Min, ImVec2(m_iRect.Min.x + m_fWidth, m_iRect.Max.y), Colors::m_iText);

			Window::m_iDrawPos.y += 20.f;
			return m_fValue;
		}

		void SliderFloat(std::string m_sName, float m_fMin, float m_fMax, float* m_pValue)
		{
			*m_pValue = SliderHandle(m_sName.c_str(), m_fMin, m_fMax, *m_pValue, 2);
		}

		void SliderInt(std::string m_sName, int m_iMin, int m_iMax, int* m_pValue)
		{
			*m_pValue = static_cast<int>(SliderHandle(m_sName.c_str(), static_cast<float>(m_iMin), static_cast<float>(m_iMax), static_cast<float>(*m_pValue), 0));
		}
	}

	namespace Configbox
	{

		int Top(char* m_cName, size_t m_sLength)
		{
			Groupbox::AddFull(50.f);

			int m_iReturnType = 0;

			// Save Button
			ImRect m_iSaveButton(Window::m_iDrawPos + ImVec2(8.f, 10.f), Window::m_iDrawPos + ImVec2(78.f, 40.f));
			{
				Window::m_pDraw->AddRectFilled(m_iSaveButton.Min, m_iSaveButton.Max, Colors::m_iItem0, 3.f);

				Window::m_pDraw->AddText(Font::m_pIcons, Font::m_pIcons->FontSize, m_iSaveButton.Min + ImVec2(10.f, 7.f), Colors::m_iText, "*");
				Window::m_pDraw->AddText(m_iSaveButton.Min + ImVec2(30.f, 5.f), Colors::m_iText, "Save");

				if (Item::ButtonBehavior(m_iSaveButton))
					m_iReturnType = 1;
			}

			// Input Box
			ImRect m_iInputBox(ImVec2(m_iSaveButton.Max.x + 10.f, m_iSaveButton.Min.y), ImVec2(m_iSaveButton.Max.x + 200.f, m_iSaveButton.Max.y));
			{
				Window::m_pDraw->AddRectFilled(m_iInputBox.Min, m_iInputBox.Max, Colors::m_iPopupBG, 3.f);

				ImGui::SetCursorPos(m_iInputBox.Min + ImVec2(2.f, Window::m_pThis->Scroll.y + 2.f) - Window::m_pThis->Pos);
				ImGui::SetNextItemWidth(m_iInputBox.Max.x - m_iInputBox.Min.x - 4.f);

				ImGui::PushStyleColor(ImGuiCol_Text, Colors::m_iText);
				ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4());
				ImGui::PushStyleColor(ImGuiCol_TextSelectedBg, ImVec4());
				ImGui::InputText(Item::GetID(), m_cName, m_sLength, 0);
				ImGui::PopStyleColor(3);

			}

			// Create Button
			ImRect m_iCreateButton(ImVec2(m_iInputBox.Max.x + 10.f, m_iInputBox.Min.y), ImVec2(m_iInputBox.Max.x + 90.f, m_iInputBox.Max.y));
			{
				Window::m_pDraw->AddRectFilled(m_iCreateButton.Min, m_iCreateButton.Max, Colors::m_iItem0, 3.f);

				Window::m_pDraw->AddText(Font::m_pIcons, Font::m_pIcons->FontSize, m_iCreateButton.Min + ImVec2(10.f, 7.f), Colors::m_iText, "/");
				Window::m_pDraw->AddText(m_iCreateButton.Min + ImVec2(30.f, 5.f), Colors::m_iText, "Create");

				if (Item::ButtonBehavior(m_iCreateButton))
					m_iReturnType = 2;
			}

			// Refresh Button
			ImRect m_iRefreshButton(ImVec2(m_iCreateButton.Max.x + 10.f, m_iCreateButton.Min.y), ImVec2(m_iCreateButton.Max.x + 80.f, m_iCreateButton.Max.y));
			{
				Window::m_pDraw->AddRectFilled(m_iRefreshButton.Min, m_iRefreshButton.Max, Colors::m_iItem0, 3.f);

				//Window::m_pDraw->AddText(Font::m_pIcons, Font::m_pIcons->FontSize, m_iRefreshButton.Min + ImVec2(10.f, 7.f), Colors::m_iText, "/");
				Window::m_pDraw->AddText(m_iRefreshButton.Min + ImVec2(10.f, 7.f), Colors::m_iText, "Refresh");

				if (Item::ButtonBehavior(m_iRefreshButton))
					m_iReturnType = 3;
			}

			// Import From Clipboard Button
			ImRect m_iImportButton(ImVec2(m_iRefreshButton.Max.x + 10.f, m_iRefreshButton.Min.y), ImVec2(m_iRefreshButton.Max.x + 80.f, m_iRefreshButton.Max.y));
			{
				Window::m_pDraw->AddRectFilled(m_iImportButton.Min, m_iImportButton.Max, Colors::m_iItem0, 3.f);

				//Window::m_pDraw->AddText(Font::m_pIcons, Font::m_pIcons->FontSize, m_iRefreshButton.Min + ImVec2(10.f, 7.f), Colors::m_iText, "/");
				Window::m_pDraw->AddText(m_iImportButton.Min + ImVec2(10.f, 7.f), Colors::m_iText, "Import");

				if (Item::ButtonBehavior(m_iImportButton))
					m_iReturnType = 4;
			}

			return m_iReturnType;
		}

		int Add(std::string m_sName, const char* m_pModifyDate = nullptr, const char* m_pAuthor = nullptr,bool m_bHighLight = false)
		{
			if (m_bHighLight)
			{
				auto old = Colors::m_iMenuAltBG;
				Colors::m_iMenuAltBG = ImColor(100,100,100);
				Groupbox::AddFull(50.f);
				Colors::m_iMenuAltBG = old;
			}
			else
			{
				Groupbox::AddFull(50.f);
			}

			float m_fWidth = Groupbox::m_fWidth * 2.f + 5.f;

			// Info
			{
				Window::m_pDraw->AddText(Window::m_iDrawPos + ImVec2(10.f, 5.f), Colors::m_iText, m_sName.c_str());

				float m_fAuthorTextOffset = 0.f;

				if (m_pModifyDate)
				{
					static const char* m_pPrefix = "Modified: ";
					static float m_fPrefixWidth = Font::m_pDefault->CalcTextSizeA(Font::m_pDefault->FontSize, FLT_MAX, 0.f, m_pPrefix).x;

					Window::m_pDraw->AddText(Window::m_iDrawPos + ImVec2(10.f, 25.f), Colors::m_iTextAlt, m_pPrefix);
					Window::m_pDraw->AddText(Window::m_iDrawPos + ImVec2(10.f + m_fPrefixWidth, 25.f), Colors::m_iText, m_pModifyDate);

					m_fAuthorTextOffset = m_fPrefixWidth + Font::m_pDefault->CalcTextSizeA(Font::m_pDefault->FontSize, FLT_MAX, 0.f, m_pModifyDate).x + 10.f;
				}

				if (m_pAuthor)
				{
					static const char* m_pPrefix = "Author: ";
					static float m_fPrefixWidth = Font::m_pDefault->CalcTextSizeA(Font::m_pDefault->FontSize, FLT_MAX, 0.f, m_pPrefix).x;

					Window::m_pDraw->AddText(Window::m_iDrawPos + ImVec2(10.f + m_fAuthorTextOffset, 25.f), Colors::m_iTextAlt, m_pPrefix);
					Window::m_pDraw->AddText(Window::m_iDrawPos + ImVec2(10.f + m_fAuthorTextOffset + m_fPrefixWidth, 25.f), Colors::m_iText, m_pAuthor);
				}
			}

			int m_iReturnType = 0;

			// Load Button
			ImRect m_iLoadButton(Window::m_iDrawPos + ImVec2(m_fWidth - 78.f, 10.f), Window::m_iDrawPos + ImVec2(m_fWidth - 8.f, 40.f));
			{
				Window::m_pDraw->AddRectFilled(m_iLoadButton.Min, m_iLoadButton.Max, Colors::m_iItem0, 3.f);

				Window::m_pDraw->AddText(Font::m_pIcons, Font::m_pIcons->FontSize, m_iLoadButton.Min + ImVec2(10.f, 7.f), Colors::m_iText, (m_bHighLight ? "*" : "+"));
				Window::m_pDraw->AddText(m_iLoadButton.Min + ImVec2(30.f, 5.f), Colors::m_iText, (m_bHighLight ? "Save" : "Load"));

				if (Item::ButtonBehavior(m_iLoadButton))
				{
					m_iReturnType = 1;
					if (m_bHighLight)
					{
						m_iReturnType = 4;
					}
				}
			}

			// Delete Icon
			ImVec2 m_iPosition(m_iLoadButton.Min + ImVec2(-25.f, 7.f));
			{
				Window::m_pDraw->AddText(Font::m_pIcons, Font::m_pIcons->FontSize, m_iPosition, Colors::m_iText, "-");

				if (Item::ButtonBehavior(ImRect(m_iPosition, m_iPosition + ImVec2(Font::m_pIcons->FontSize, Font::m_pIcons->FontSize))))
					m_iReturnType = 2;
			}

			// Export Icon
			ImVec2 m_iExportButtonPosition(m_iLoadButton.Min + ImVec2(-50.f, 7.f));
			{
				Window::m_pDraw->AddText(Font::m_pIcons, Font::m_pIcons->FontSize, m_iExportButtonPosition, Colors::m_iText, "*");

				if (Item::ButtonBehavior(ImRect(m_iExportButtonPosition, m_iExportButtonPosition + ImVec2(Font::m_pIcons->FontSize, Font::m_pIcons->FontSize))))
					m_iReturnType = 3;
			}

			return m_iReturnType;
		}
	}
	namespace Scriptbox
	{
		int Top()
		{
			Groupbox::AddFull(50.f);

			int m_iReturnType = 0;

			// Refresh Button
			ImRect m_iRefreshButton(Window::m_iDrawPos + ImVec2(8.f, 10.f), Window::m_iDrawPos + ImVec2(78.f, 40.f));
			{
				Window::m_pDraw->AddRectFilled(m_iRefreshButton.Min, m_iRefreshButton.Max, Colors::m_iItem0, 3.f);

				//Window::m_pDraw->AddText(Font::m_pIcons, Font::m_pIcons->FontSize, m_iRefreshButton.Min + ImVec2(10.f, 7.f), Colors::m_iText, "/");
				Window::m_pDraw->AddText(m_iRefreshButton.Min + ImVec2(10.f, 7.f), Colors::m_iText, "Refresh");

				if (Item::ButtonBehavior(m_iRefreshButton))
					m_iReturnType = 1;
			}

			// Open Folder Button
			ImRect m_iOpenFolderButton(ImVec2(m_iRefreshButton.Max.x + 10.f, m_iRefreshButton.Min.y), ImVec2(m_iRefreshButton.Max.x + 105.f, m_iRefreshButton.Max.y));
			{
				Window::m_pDraw->AddRectFilled(m_iOpenFolderButton.Min, m_iOpenFolderButton.Max, Colors::m_iItem0, 3.f);

				Window::m_pDraw->AddText(m_iOpenFolderButton.Min + ImVec2(10.f, 7.f), Colors::m_iText, "Open Folder");

				if (Item::ButtonBehavior(m_iOpenFolderButton))
					m_iReturnType = 2;
			}

			return m_iReturnType;
		}

		int Add(std::string m_sName, const char* m_pModifyDate = nullptr, const char* m_pAuthor = nullptr, bool m_bHighLight = false)
		{
			Groupbox::AddFull(50.f);
			
			float m_fWidth = Groupbox::m_fWidth * 2.f + 5.f;

			// Info
			{
				Window::m_pDraw->AddText(Window::m_iDrawPos + ImVec2(10.f, 5.f), Colors::m_iText, m_sName.c_str());

				float m_fAuthorTextOffset = 0.f;

				if (m_pModifyDate)
				{
					static const char* m_pPrefix = "Modified: ";
					static float m_fPrefixWidth = Font::m_pDefault->CalcTextSizeA(Font::m_pDefault->FontSize, FLT_MAX, 0.f, m_pPrefix).x;

					Window::m_pDraw->AddText(Window::m_iDrawPos + ImVec2(10.f, 25.f), Colors::m_iTextAlt, m_pPrefix);
					Window::m_pDraw->AddText(Window::m_iDrawPos + ImVec2(10.f + m_fPrefixWidth, 25.f), Colors::m_iText, m_pModifyDate);

					m_fAuthorTextOffset = m_fPrefixWidth + Font::m_pDefault->CalcTextSizeA(Font::m_pDefault->FontSize, FLT_MAX, 0.f, m_pModifyDate).x + 10.f;
				}

				if (m_pAuthor)
				{
					static const char* m_pPrefix = "Author: ";
					static float m_fPrefixWidth = Font::m_pDefault->CalcTextSizeA(Font::m_pDefault->FontSize, FLT_MAX, 0.f, m_pPrefix).x;

					Window::m_pDraw->AddText(Window::m_iDrawPos + ImVec2(10.f + m_fAuthorTextOffset, 25.f), Colors::m_iTextAlt, m_pPrefix);
					Window::m_pDraw->AddText(Window::m_iDrawPos + ImVec2(10.f + m_fAuthorTextOffset + m_fPrefixWidth, 25.f), Colors::m_iText, m_pAuthor);
				}
			}

			int m_iReturnType = 0;

			// Load Button
			ImRect m_iLoadButton(Window::m_iDrawPos + ImVec2(m_fWidth - 78.f, 10.f), Window::m_iDrawPos + ImVec2(m_fWidth - 8.f, 40.f));
			{
				Window::m_pDraw->AddRectFilled(m_iLoadButton.Min, m_iLoadButton.Max, Colors::m_iItem0, 3.f);
				if (!m_bHighLight)
				{
					Window::m_pDraw->AddText(Font::m_pIcons, Font::m_pIcons->FontSize, m_iLoadButton.Min + ImVec2(10.f, 7.f), Colors::m_iText, (m_bHighLight ? "*" : "+"));
				}
				Window::m_pDraw->AddText(m_iLoadButton.Min + (m_bHighLight ? ImVec2(15.f, 5.f) : ImVec2(30.f, 5.f)), Colors::m_iText, (m_bHighLight ? "Unload" : "Load"));

				if (Item::ButtonBehavior(m_iLoadButton))
				{
					m_iReturnType = 1;
					if (m_bHighLight)
					{
						m_iReturnType = 2;	
					}
				}
			}

			return m_iReturnType;
		}
	}
	namespace Tabs
	{
		char m_cIcon[32];
		char m_cName[16][32];
		int m_iSize = 0;
		int m_iSelected = 0;

		float m_fTabSize = 200.f;
		bool m_bShortMode = false;

		void Add(const char* name, char icon = '\0')
		{
			strcpy_s(m_cName[m_iSize], name);
			m_cIcon[m_iSize] = icon;

			m_iSize++;
		}

		void Render(ImVec2 m_iPosition)
		{
			for (int i = 0; Tabs::m_iSize > i; ++i)
			{
				char buf[255] = "###Tab";
				sprintf(buf, "%d", i);
				unsigned int m_iID = Window::m_pThis->GetID(UniqueID::Generate());

				bool m_bSelected = m_iSelected == i;

				char m_cIcon[2] = { Tabs::m_cIcon[i], '\0' };
				const char* m_pName = Tabs::m_cName[i];
				char m_cName[2] = { m_pName[0], '\0'};

				ImVec2 m_FullSize = ImGui::CalcTextSize(m_pName);
				m_FullSize.x += ImGui::CalcTextSize(m_cIcon).x;

				ImVec2 m_iLeftPanel(m_fTabSize, Window::m_pThis->Size.y);
				ImVec2 AddPos = Window::m_pThis->Pos + m_iLeftPanel;
				ImRect m_rRange = { ImVec2(1, m_iPosition.y - 10) , ImVec2(AddPos.x /* - 40*/, m_iPosition.y + m_FullSize.y + 10) };

				if (m_bSelected)
				{
					Window::m_pDraw->AddRectFilled(m_rRange.Min, m_rRange.Max, Colors::m_iMenuShadow);

					// leave 40x40 for triangle !! warning !! ugly
					/*
					ImVec2 m_Point1 = ImVec2(m_SelectedShadow.Max.x, m_SelectedShadow.Min.y);
					ImVec2 m_Point2 = ImVec2(m_SelectedShadow.Max.x, m_SelectedShadow.Max.y);
					ImVec2 m_Point3 = ImVec2(m_SelectedShadow.Max.x + 40, m_SelectedShadow.Min.y + (m_SelectedShadow.Max.y - m_SelectedShadow.Min.y) * 0.5);

					Window::m_pDraw->AddTriangleFilled(m_Point1, m_Point2, m_Point3, Colors::m_iMenuShadow);
					*/
				}
				if (!m_bSelected)
				{
					ImVec4 m_vHoveredCol = ImColor(Colors::m_iMenuShadow);
					m_vHoveredCol.w = clamp(Fade::m_vAnimations.second[m_iID] / 255.f, 0.f, 0.4f);
					Window::m_pDraw->AddRectFilled(m_rRange.Min, m_rRange.Max, ImColor(m_vHoveredCol));
				}

				// icon && text
				if(m_bSelected)
					ImRotateStart();
				Window::m_pDraw->AddText(Font::m_pIcons, Font::m_pIcons->FontSize, m_iPosition, Colors::m_iText, m_cIcon);
				if(m_bSelected)
					ImRotateEnd(0.001f * GetTickCount());

				Window::m_pDraw->AddText(Font::m_pDefault, Font::m_pDefault->FontSize, m_iPosition + ImVec2(Font::m_pIcons->FontSize * 1.5f, -2.f), Colors::m_iText, (m_bShortMode ? m_cName : m_pName));
				if (m_bSelected)
					Window::m_pDraw->AddText(Font::m_pDefault, Font::m_pDefault->FontSize, m_iPosition + ImVec2(Font::m_pIcons->FontSize * 1.5f + 1.f, -2.f), Colors::m_iText, (m_bShortMode ? m_cName : m_pName));

				
				Fade::OnPreAnimation(m_iID);

				float m_fNameWidth = Font::m_pDefault->CalcTextSizeA(Font::m_pDefault->FontSize, FLT_MAX, 0.f, m_pName).x;
				if (!m_bSelected && Item::ButtonBehavior(m_rRange))
				{
					m_iSelected = i;
					Fade::OnTabSwitch();
				}

				Fade::OnPostAnimation(m_iID, m_bSelected, m_bHovered);

				m_iPosition.y += 40.f;
			}
		}
	}

	namespace UserBottomInfo
	{
		char m_cName[32] = "Guest";
		char m_cExpire[32] = "Lifetime";
	}

	bool BeginMainMenu(const char* m_pName = nullptr)
	{
		static const char* m_pDefaultName = "###MainMenu";
		static IDirect3DTexture9* steamAvatar = nullptr;
		if (steamAvatar == nullptr)
		{
			HMODULE steamapi_module = GetModuleHandleA("steam_api.dll");

			void* hsteampipe = ((void* (__cdecl*)())GetProcAddress(steamapi_module, "SteamAPI_GetHSteamPipe"))();
			if (hsteampipe)
			{
				void* hsteamuser = ((void* (__cdecl*)())GetProcAddress(steamapi_module, "SteamAPI_GetHSteamUser"))();
				if (hsteamuser)
				{
					SteamClient* steamclient = ((SteamClient * (__cdecl*)())GetProcAddress(steamapi_module, "SteamClient"))();
					if (steamclient)
					{
						SteamUser* steamuser = steamclient->GetISteamUser(hsteamuser, hsteampipe, "SteamUser021");
						SteamFriends* steamfriends = steamclient->GetISteamFriends(hsteamuser, hsteampipe, "SteamFriends017");
						SteamUtils* steamUtils = steamclient->GetISteamUtils(hsteampipe, "SteamUtils010");
						if (steamuser && steamfriends && steamUtils)
						{
							std::uint64_t steamid = 0;

							steamuser->GetSteamID(&steamid);

							BYTE* avatar_data = nullptr;
							int avatar_size = 0;

							BYTE* buf = nullptr;
							uint32 width, height;

							int texid = steamfriends->getSmallFriendAvatar(steamid); //actually its middle size lol
							if (texid != -1)
							{
								steamUtils->GetImageSize(texid, &width, &height);
								if (width && height)
								{
									buf = (BYTE*)malloc(width * height * 4);

									if (steamUtils->getImageRGBA(texid, buf, width * height * 4))
									{
										avatar_data = buf;
										avatar_size = width * height * 4;
										auto res = m_pDevice->CreateTexture(width, height, 1, D3DUSAGE_DYNAMIC, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &steamAvatar, nullptr);
										auto CopyConvert = [](const uint8_t* rgba, uint8_t* out, const size_t size)
										{
											auto in = reinterpret_cast<const uint32_t*>(rgba);
											auto buf = reinterpret_cast<uint32_t*>(out);
											for (auto i = 0u; i < (size / 4); ++i)
											{
												const auto pixel = *in++;
												*buf++ = (pixel & 0xFF00FF00) | ((pixel & 0xFF0000) >> 16) | ((pixel & 0xFF) << 16);
											}
										};

										std::vector<uint8_t> texData;
										texData.resize(width * height * 4);

										CopyConvert((uint8_t*)buf, texData.data(), width * height * 4);

										D3DLOCKED_RECT rect;
										res = steamAvatar->LockRect(0, &rect, nullptr, D3DLOCK_DISCARD);

										auto src = texData.data();
										auto dst = reinterpret_cast<uint8_t*>(rect.pBits);
										for (auto y = 0u; y < height; ++y)
										{
											std::copy(src, src + (width * 4), dst);

											src += width * 4;
											dst += rect.Pitch;
										}

										res = steamAvatar->UnlockRect(0);

										if (buf)
										{
											free(buf);
										}

										steam_name = steamfriends->GetPersonName();
										if (steam_name.size() > 15)
										{
											steam_name.resize(15);
										}
									}
								}
							}
						}
					}
				}
			}
		}
		ImGui::SetNextWindowSize(ImVec2(900.f, 650.f));
		if (!ImGui::Begin(m_pDefaultName, nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoBackground))
		{
			Window::m_pThis = nullptr;
			return false;
		}

		Window::m_pThis = ImGui::GetCurrentWindow();
		Window::m_pDraw = Window::m_pThis->DrawList;
		Window::m_iRect = Window::m_pThis->Rect();

		ImVec2 m_iLeftPanel(Tabs::m_fTabSize, Window::m_pThis->Size.y);


		Window::m_pDraw->AddRectFilled(ImVec2(Window::m_pThis->Pos.x + m_iLeftPanel.x, Window::m_pThis->Pos.y), Window::m_pThis->Pos + Window::m_pThis->Size, Colors::m_iMenuBG);

		
		Window::m_pDraw->AddRectFilled(Window::m_pThis->Pos, Window::m_pThis->Pos + m_iLeftPanel, Colors::m_iMenuLeftBG);
		/*
		ImVec2 m_iTriangles[][3] =
		{
			{ ImVec2(5.f, 50.f),	ImVec2(60.f, 25.f),		ImVec2(55.f, 90.f)		},
			{ ImVec2(116.f, 69.f),	ImVec2(180.f, 114.f),	ImVec2(105.f, 148.f)	},
			{ ImVec2(30.f, 160.f),	ImVec2(84.f, 180.f),	ImVec2(38.f, 220.f)		},
			{ ImVec2(88.f, 265.f),	ImVec2(175.f, 250.f),	ImVec2(140.f, 328.f)	},
			{ ImVec2(26.f, 366.f),	ImVec2(58.f, 336.f),	ImVec2(68.f, 380.f)		},
			{ ImVec2(86.f, 442.f),	ImVec2(160.f, 422.f),	ImVec2(134.f, 495.f)	},
		};
		for (int i = 0; 6 > i; ++i)
			Window::m_pDraw->AddTriangleFilled(Window::m_pThis->Pos + m_iTriangles[i][0], Window::m_pThis->Pos + m_iTriangles[i][1], Window::m_pThis->Pos + m_iTriangles[i][2], Colors::m_iMenuBG);
		*/
		// Title
		if(!Tabs::m_bShortMode)
		{
			if (m_pName)
			{
				ImVec2 m_iPosition((m_iLeftPanel.x * 0.5f) - (Font::m_pTitle->CalcTextSizeA(Font::m_pTitle->FontSize, FLT_MAX, 0.f, m_pName).x * 0.5f), 50.f);
				m_iPosition += Window::m_pThis->Pos;

				Window::m_pDraw->AddText(Font::m_pTitle, Font::m_pTitle->FontSize, m_iPosition, Colors::m_iText, m_pName);

				m_iPosition.y += 20.f;
				Window::m_pDraw->AddText(Font::m_pTitle, Font::m_pTitle->FontSize * 0.75, m_iPosition, Colors::m_iText, crypt_str("By LauncherSU.net"));
			}
			else
			{
				static IDirect3DTexture9* m_pLogo = nullptr;
				if (!m_pLogo) D3DXCreateTextureFromFileInMemory(UI::m_pDevice, m_uLogo, sizeof(m_uLogo), &m_pLogo);

				ImVec2 m_iSize(625.f, 625.f);
				m_iSize *= 0.275f;

				m_iSize.x = roundf(m_iSize.x);
				m_iSize.y = roundf(m_iSize.y);

				ImVec2 m_iPosition(Window::m_pThis->Pos + ImVec2(m_iLeftPanel.x * 0.5f - m_iSize.x * 0.5f, 0.f));
				ImRotateStart();
				Window::m_pDraw->AddImage(m_pLogo, m_iPosition, m_iPosition + m_iSize, ImVec2(0.f, 0.f), ImVec2(1.f, 1.f), Colors::m_iText);
				ImRotateEnd(0.0001f * GetTickCount());
			}
		}
		else {
			ImVec2 m_iPosition((m_iLeftPanel.x * 0.5f) - (Font::m_pTitle->CalcTextSizeA(Font::m_pTitle->FontSize, FLT_MAX, 0.f, "B").x * 0.5f), 50.f);
			m_iPosition += Window::m_pThis->Pos;

			Window::m_pDraw->AddText(Font::m_pTitle, Font::m_pTitle->FontSize, m_iPosition, Colors::m_iText, "B");
		}

		// Tabs
		{
			Tabs::Render(ImVec2(Window::m_pThis->Pos + ImVec2(m_iLeftPanel.x * 0.25f, 195.f)));
		}

		// Profile Picture
		{
			ImVec2 m_iPosition(Window::m_pThis->Pos + ImVec2(m_iLeftPanel.x * (Tabs::m_bShortMode ? 0.5f : 0.20f ), Window::m_pThis->Size.y - 50.f + Font::m_pIcons->FontSize * 0.5f));
			Window::m_pDraw->AddCircleFilled(m_iPosition, Font::m_pIcons->FontSize * 0.85f, Colors::m_iText, IM_DRAWLIST_CIRCLE_AUTO_SEGMENT_MAX);

			Window::m_pDraw->AddCircleImageFilled(steamAvatar, m_iPosition, Font::m_pIcons->FontSize * 0.85f, ImColor(255, 255, 255), IM_DRAWLIST_CIRCLE_AUTO_SEGMENT_MAX);

		}
		
		// User Info
		if (!Tabs::m_bShortMode)
		{
			ImVec2 m_iPosition(Window::m_pThis->Pos + ImVec2(m_iLeftPanel.x * 0.30f, Window::m_pThis->Size.y - 50.f));

			Window::m_pDraw->AddText(Font::m_pUserInfo, Font::m_pUserInfo->FontSize, m_iPosition + ImVec2(0.f, -6.f), Colors::m_iText, steam_name.c_str());
			Window::m_pDraw->AddText(Font::m_pUserInfo, Font::m_pUserInfo->FontSize, m_iPosition + ImVec2(1.f, -6.f), Colors::m_iText, steam_name.c_str());


			Window::m_pDraw->AddText(Font::m_pUserInfo, Font::m_pUserInfo->FontSize, m_iPosition + ImVec2(0.f, 6.f), Colors::m_iText, UserBottomInfo::m_cExpire);
		}

		// Calculations
		{
			Groupbox::m_fPositionHorizontal = m_iLeftPanel.x + 10.f;
			Groupbox::m_fPositionVertical[0] = -Window::m_pThis->Scroll.y;
			Groupbox::m_fPositionVertical[1] = -Window::m_pThis->Scroll.y;
			Groupbox::m_fWidth = (Window::m_pThis->Size.x - m_iLeftPanel.x - 27.f) * 0.5f;
		}

		return true;
	}

	void EndMainMenu()
	{
		if (Window::m_pThis)
		{
			ImVec2 m_iLeftPanel(Window::m_pThis->Pos + ImVec2(Tabs::m_fTabSize, 0.f));

			//Window::m_pDraw->AddRectFilled(m_iLeftPanel, m_iLeftPanel + ImVec2(Window::m_pThis->Size.x, 10.f), Colors::m_iMenuBG);
			//Window::m_pDraw->AddRectFilled(m_iLeftPanel + ImVec2(0.f, Window::m_pThis->Size.y - 10.f), m_iLeftPanel + Window::m_pThis->Size, Colors::m_iMenuBG);

			float m_fLongest = fmaxf(Groupbox::m_fPositionVertical[0], Groupbox::m_fPositionVertical[1]);
			if (m_fLongest > 0.f)
				m_fLongest += Window::m_pThis->Scroll.y + 5.f;

			ImGui::SetCursorPosY(fmaxf(0.f, m_fLongest));
			ImGui::End();
		}
	}

	/*
	*	Draw Part
	*/
	void NewFrame()
	{
		ImGui_ImplDX9_NewFrame();
		ImGui_ImplWin32_NewFrame();
		ImGui::NewFrame();

		UniqueID::Reset();
		Fade::OnNewFrame();
		if (hooks::menu_open)
		{
			if (Tabs::m_bShortMode)
			{
				Tabs::m_fTabSize -= 4;
			}
			else
			{
				Tabs::m_fTabSize += 4;
			}
			Tabs::m_fTabSize = clamp(Tabs::m_fTabSize, 60.f, 200.f);
		}

		Item::m_uID = 0;
	}

	void EndFrame()
	{
		ImGui::EndFrame();
		ImGui::Render();
		ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
	}
	
    void WndProcHandle(HWND wnd, UINT msg, WPARAM wParam, LPARAM lParam)
    {
		if (Keybind::m_pValue)
		{
			int m_iKey = -1;
			switch (msg)
			{
			case WM_LBUTTONDOWN: m_iKey = VK_LBUTTON; break;
			case WM_RBUTTONDOWN: m_iKey = VK_RBUTTON; break;
			case WM_MBUTTONDOWN: m_iKey = VK_MBUTTON; break;
			case WM_XBUTTONDOWN: m_iKey = GET_XBUTTON_WPARAM(wParam) == XBUTTON1 ? VK_XBUTTON1 : VK_XBUTTON2; break;
			case WM_KEYDOWN: case WM_SYSKEYDOWN:
				{
					int m_iExtended = (lParam & 0x1000000) != 0;
					switch (wParam)
					{
					case VK_SHIFT: m_iKey = MapVirtualKeyA((lParam & 0xFF0000) >> 16, MAPVK_VSC_TO_VK_EX); break;
					case VK_CONTROL: m_iKey = m_iExtended ? VK_RCONTROL : VK_LCONTROL; break;
					case VK_MENU: m_iKey = m_iExtended ? VK_RMENU : VK_LMENU; break;
					default: m_iKey = wParam; break;
					}
				}
				break;
			}

			if (m_iKey > 0)
			{
				switch(m_iKey)
				{
				case VK_LBUTTON:
					*Keybind::m_pValue = MOUSE_LEFT;
					Keybind::m_pValue = nullptr;
					return;
					break;
				case VK_RBUTTON:
					*Keybind::m_pValue = MOUSE_RIGHT;
					Keybind::m_pValue = nullptr;
					return;
					break;
				case VK_XBUTTON1:
					*Keybind::m_pValue = MOUSE_4;
					Keybind::m_pValue = nullptr;
					return;
					break;
				case VK_XBUTTON2:
					*Keybind::m_pValue = MOUSE_5;
					Keybind::m_pValue = nullptr;
					return;
					break;
				case VK_MBUTTON:
					*Keybind::m_pValue = MOUSE_MIDDLE;
					Keybind::m_pValue = nullptr;
					return;
					break;
				case VK_LSHIFT:
					*Keybind::m_pValue = KEY_LSHIFT;
					Keybind::m_pValue = nullptr;
					return;
					break;
				case VK_LCONTROL:
					*Keybind::m_pValue = KEY_LCONTROL;
					Keybind::m_pValue = nullptr;
					return;
					break;
				case VK_LMENU:
					*Keybind::m_pValue = KEY_LALT;
					Keybind::m_pValue = nullptr;
					return;
					break;
				case VK_RSHIFT:
					*Keybind::m_pValue = KEY_RSHIFT;
					Keybind::m_pValue = nullptr;
					return;
					break;
				case VK_RCONTROL:
					*Keybind::m_pValue = KEY_RCONTROL;
					Keybind::m_pValue = nullptr;
					return;
					break;
				case VK_RMENU:
					*Keybind::m_pValue = KEY_RALT;
					Keybind::m_pValue = nullptr;
					return;
					break;
				}
				*Keybind::m_pValue = m_iKey == VK_ESCAPE ? 0 : (int)(m_inputsys()->VirtualKeyToButtonCode(m_iKey));
				Keybind::m_pValue = nullptr;
			}

			return;
		}

		return;//ImGui_ImplWin32_WndProcHandler(wnd, msg, wParam, lParam);
    }

}