#include "menu.h"
#include "UI.hpp"
#include "../constchars.h"
#include "../cheats/misc/logs.h"
#include <unordered_map>
#include <ShlObj_core.h>
#include "../hooks/hooks.hpp"
#include "../clip/clip.h"

std::vector <std::string> scripts;
std::string editing_script;

auto selected_script = -1;
auto loaded_editing_script = false;

static auto should_update = true;
static auto should_update_lua = true;
static std::vector <std::string> files;
IDirect3DTexture9* all_skins[36];

std::string get_config_dir()
{
	std::string folder;
	static TCHAR path[MAX_PATH];

	if (SUCCEEDED(SHGetFolderPath(NULL, 0x001a, NULL, NULL, path)))
		folder = std::string(path) + crypt_str("\\BaiMaoSense\\Configs\\");

	CreateDirectory(folder.c_str(), NULL);
	return folder;
}

void load_config()
{
	if (cfg_manager->files.empty())
		return;

	g_cfg.is_loading_cfg = true;

	cfg_manager->load(cfg_manager->files.at(g_cfg.selected_config), false);

	c_lua::get().unload_all_scripts();

	for (auto& script : g_cfg.scripts.scripts)
		c_lua::get().load_script(c_lua::get().get_script_id(script));

	scripts = c_lua::get().scripts;

	if (selected_script >= scripts.size())
		selected_script = scripts.size() - 1; //-V103

	for (auto& current : scripts)
	{
		if (current.size() >= 5 && current.at(current.size() - 1) == 'c')
			current.erase(current.size() - 5, 5);
		else if (current.size() >= 4)
			current.erase(current.size() - 4, 4);
	}

	for (auto i = 0; i < g_cfg.skins.skinChanger.size(); ++i)
		all_skins[i] = nullptr;

	g_cfg.scripts.scripts.clear();

	cfg_manager->load(cfg_manager->files.at(g_cfg.selected_config), true);
	cfg_manager->config_files();

	eventlogs::get().add(crypt_str("Loaded ") + files.at(g_cfg.selected_config) + crypt_str(" config"), false);

	g_cfg.is_loading_cfg = false;
}

void save_config()
{
	if (cfg_manager->files.empty())
		return;

	g_cfg.scripts.scripts.clear();

	for (auto i = 0; i < c_lua::get().scripts.size(); ++i)
	{
		auto script = c_lua::get().scripts.at(i);

		if (c_lua::get().loaded.at(i))
			g_cfg.scripts.scripts.emplace_back(script);
	}

	cfg_manager->save(cfg_manager->files.at(g_cfg.selected_config));
	cfg_manager->config_files();

	eventlogs::get().add(crypt_str("Saved ") + files.at(g_cfg.selected_config) + crypt_str(" config"), false);
}

void remove_config()
{
	if (cfg_manager->files.empty())
		return;

	eventlogs::get().add(crypt_str("Removed ") + files.at(g_cfg.selected_config) + crypt_str(" config"), false);

	cfg_manager->remove(cfg_manager->files.at(g_cfg.selected_config));
	cfg_manager->config_files();

	files = cfg_manager->files;

	if (g_cfg.selected_config >= files.size())
		g_cfg.selected_config = files.size() - 1; //-V103

	for (auto& current : files)
		if (current.size() > 2)
			current.erase(current.size() - 4, 4);
}

void add_config()
{
	auto empty = true;

	for (auto current : g_cfg.new_config_name)
	{
		if (current != ' ')
		{
			empty = false;
			break;
		}
	}

	if (empty)
		g_cfg.new_config_name = crypt_str("config");

	eventlogs::get().add(crypt_str("Added ") + g_cfg.new_config_name + crypt_str(" config"), false);

	if (g_cfg.new_config_name.find(crypt_str(".bms")) == std::string::npos)
		g_cfg.new_config_name += crypt_str(".bms");

	cfg_manager->save(g_cfg.new_config_name, true);
	cfg_manager->config_files();

	for (int i = 0; i < cfg_manager->files.size(); i++)
	{
		if (g_cfg.new_config_name == cfg_manager->files[i])
		{
			g_cfg.selected_config = i;
		}
	}

	files = cfg_manager->files;

	for (auto& current : files)
		if (current.size() > 2)
			current.erase(current.size() - 4, 4);
}

void ImDrawList::AddTextOutline(const ImFont* font, float font_size, const ImVec2& pos, ImU32 col, const char* text_begin, const char* text_end = (char*)0)
{
	const auto col_bg = ImColor(0, 0, 0, ((col >> IM_COL32_A_SHIFT) & 0xFF));

	AddText(font, font_size, pos + ImVec2(1, 1), col_bg, text_begin, text_end);
	AddText(font, font_size, pos - ImVec2(1, 1), col_bg, text_begin, text_end);
	AddText(font, font_size, pos + ImVec2(1, -1), col_bg, text_begin, text_end);
	AddText(font, font_size, pos - ImVec2(1, -1), col_bg, text_begin, text_end);

	AddText(font, font_size, pos, col, text_begin, text_end);
}

namespace Menu
{
	static char cName[128] = {};
	std::string preview = crypt_str("None");
	void Indicators() // Ryzen 7 1700X �� RX 6700 XT ���������Լ�˷ѵ�14���ҵ�fps, ���Ż������ö�
	{
		{
			ImGui::SetNextWindowPos(ImVec2(0, 0));
			ImGui::SetNextWindowSize(ImVec2(8192, 8192));
			ImGui::Begin("back", (bool*)1, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove);

			ImVec2 pos;
			ImDrawList* draw;
			pos = ImGui::GetWindowPos();
			draw = ImGui::GetWindowDrawList();

			float r, g, b;
			auto width = 0, height = 0;
			if (width == 0 || height == 0)
			{
				m_engine()->GetScreenSize(width, height); //-V807
			}
			ImGui::ColorConvertHSVtoRGB(m_globals()->m_realtime * 0.2, 1, 1, r, g, b);

			ImColor leftcol = ImColor(r, g, b), rightcol;
			rightcol = leftcol;
			if (g_cfg.custom_indicator_col)
			{
				leftcol = ImColor(g_cfg.indicator_col);
				rightcol = leftcol;
			}

			if (g_cfg.antiaim.antiaim_indicator)
			{
				int x1 = g_cfg.antiaim.antiaim_indicator_x, y1 = g_cfg.antiaim.antiaim_indicator_y;
				if (hooks::menu_open && ImGui::GetIO().MouseDown[0])
				{
					int mouse_x, mouse_y;
					auto mousexy = ImGui::GetMousePos();
					
					mouse_x = mousexy.x;
					mouse_y = mousexy.y;

					if (mouse_x > x1 && mouse_y > y1 && mouse_x < x1 + 180 && mouse_y < y1 + 70)
					{
						g_cfg.antiaim.antiaim_indicator_x = mouse_x - 90;
						g_cfg.antiaim.antiaim_indicator_y = mouse_y - 20;
					}
				}
				draw->AddRectFilled(ImVec2(x1, y1), ImVec2(x1 + 180, y1 + 27), ImColor(0, 0, 0, 40));

				draw->AddRectFilledMultiColor(ImVec2(x1, y1), ImVec2(x1 + 180, y1 + 2), leftcol, rightcol, rightcol, leftcol);
				//draw->AddRectFilledMultiColor(ImVec2(x1 + 90, y1), ImVec2(x1 + 180, y1 + 2), rightcol, leftcol, leftcol, rightcol);

				draw->AddTextOutline(UI::Font::m_pDefault, 14.f, ImVec2(x1 + 5, y1 + 8), ImColor(255, 255, 255), "ANTI-AIMBOT DEBUG");


				draw->AddRectFilledMultiColor(ImVec2(x1 + 5, y1 + 45), ImVec2(x1 + 9, y1 + 35), antiaim_fake_degree_color, antiaim_fake_degree_color, ImColor(0, 0, 0, 20), ImColor(0, 0, 0, 20));
				draw->AddRectFilledMultiColor(ImVec2(x1 + 5, y1 + 45), ImVec2(x1 + 9, y1 + 55), antiaim_fake_degree_color, antiaim_fake_degree_color, ImColor(0, 0, 0, 20), ImColor(0, 0, 0, 20));

				draw->AddTextOutline(UI::Font::m_pDefault, 16.f, ImVec2(x1 + 13, y1 + 35), ImColor(255, 255, 255), (u8"FAKE(" + std::to_string((int)antiaim_desync_degree) + u8"��)").c_str());
			}

			if (g_cfg.keybind_indicator)
			{
				int x0 = g_cfg.keybind_indicator_x, y0 = g_cfg.keybind_indicator_y;
				if (hooks::menu_open && ImGui::GetIO().MouseDown[0])
				{
					int mouse_x, mouse_y;
					auto mousexy = ImGui::GetMousePos();

					mouse_x = mousexy.x;
					mouse_y = mousexy.y;
					if (mouse_x > x0 && mouse_y > y0 && mouse_x < x0 + 180 && mouse_y < y0 + 70)
					{
						g_cfg.keybind_indicator_x = mouse_x - 90;
						g_cfg.keybind_indicator_y = mouse_y - 20;
					}
				}
				draw->AddRectFilled(ImVec2(x0, y0), ImVec2(x0 + 180, y0 + 27), ImColor(0, 0, 0, 40));

				draw->AddRectFilledMultiColor(ImVec2(x0, y0), ImVec2(x0 + 180, y0 + 2), leftcol, rightcol, rightcol, leftcol);
				//draw->AddRectFilledMultiColor(ImVec2(x0 + 90, y0), ImVec2(x0 + 180, y0 + 2), rightcol, leftcol, leftcol, rightcol);

				auto size_font = UI::Font::m_pDefault->CalcTextSizeA(14.f, FLT_MAX, -1.f, "Keybinds");

				draw->AddText(UI::Font::m_pDefault, 14.f, ImVec2(x0 + 90 - size_font.x / 2 + 1, y0 + 8), ImColor(0, 0, 0), "Keybinds");
				draw->AddText(UI::Font::m_pDefault, 14.f, ImVec2(x0 + 90 - size_font.x / 2, y0 + 7), ImColor(255, 255, 255), "Keybinds");

				otheresp::get().indicators();
				if (m_engine()->IsInGame() && g_ctx.local()->is_alive())
				{
					int i = 0;
					for (auto& indicator : otheresp::get().m_indicators)
					{
						auto y1 = i * 16;

						switch (indicator.keybind.mode)
						{
						case HOLD:
							indicator.m_text = "[holding]" + indicator.m_text;
							break;
						case TOGGLE:
							indicator.m_text = "[toggled]" + indicator.m_text;
							break;
						case ALWAYS:
							indicator.m_text = "[always]" + indicator.m_text;
							break;
						}


						draw->AddText(UI::Font::m_pDefault, 14.f, ImVec2(x0 + 5 + 1, y0 + y1 + 31), ImColor(0, 0, 0), indicator.m_text.c_str());
						draw->AddText(UI::Font::m_pDefault, 14.f, ImVec2(x0 + 5, y0 + y1 + 30), ImColor(255, 255, 255), indicator.m_text.c_str());

						i++;
					}
					if (should_update_keybinds)
					{
						otheresp::get().m_indicators.clear();
					}

				}
			}

			if (g_cfg.misc.spectators_list)
			{
				int xx = g_cfg.misc_spec_x, yy = g_cfg.misc_spec_y;
				if (hooks::menu_open && ImGui::GetIO().MouseDown[0])
				{
					int mouse_x, mouse_y;
					auto mousexy = ImGui::GetMousePos();

					mouse_x = mousexy.x;
					mouse_y = mousexy.y;
					if (mouse_x > xx && mouse_y > yy && mouse_x < xx + 180 && mouse_y < yy + 70)
					{
						g_cfg.misc_spec_x = mouse_x - 90;
						g_cfg.misc_spec_y = mouse_y - 20;
					}
				}
				draw->AddRectFilled(ImVec2(xx, yy), ImVec2(xx + 180, yy + 27), ImColor(0, 0, 0, 40));

				draw->AddRectFilledMultiColor(ImVec2(xx, yy), ImVec2(xx + 180, yy + 2), leftcol, rightcol, rightcol, leftcol);
				//draw->AddRectFilledMultiColor(ImVec2(xx + 90, yy), ImVec2(xx + 180, yy + 2), rightcol, leftcol, leftcol, rightcol);

				auto size_font = UI::Font::m_pDefault->CalcTextSizeA(14.f, FLT_MAX, -1.f, "Spectators");

				draw->AddText(UI::Font::m_pDefault, 14.f, ImVec2(xx + 90 - size_font.x / 2 + 1, yy + 8), ImColor(0, 0, 0), "Spectators");
				draw->AddText(UI::Font::m_pDefault, 14.f, ImVec2(xx + 90 - size_font.x / 2, yy + 7), ImColor(255, 255, 255), "Spectators");

				if (m_engine()->IsInGame() && g_ctx.local()->is_alive())
				{
					int validplayer = 0;
					for (int i = 1; i < m_globals()->m_maxclients; i++)
					{
						auto e = static_cast<player_t*>(m_entitylist()->GetClientEntity(i));

						if (!e)
							continue;

						if (e->is_alive())
							continue;

						if (e->IsDormant())
							continue;

						if (e->m_hObserverTarget().Get() != g_ctx.local())
							continue;

						player_info_t player_info;
						m_engine()->GetPlayerInfo(i, &player_info);

						auto x = UI::Font::m_pUserInfo->CalcTextSizeA(12.f, FLT_MAX, -1.f, player_info.szName).x + 6; //-V106
						auto y = validplayer * 16;

						draw->AddText(UI::Font::m_pUserInfo, 12.f, ImVec2(xx + 5 + 1, yy + y + 40 + 1), ImColor(0, 0, 0), player_info.szName);
						draw->AddText(UI::Font::m_pUserInfo, 12.f, ImVec2(xx + 5, yy + y + 40), ImColor(255, 255, 255), player_info.szName);

						validplayer++;
					}
				}
			}
			/*
			if (g_cfg.ragebot.indicator)
			{
				int x = g_cfg.miscbar_x, y = g_cfg.miscbar_y;
				if (hooks::menu_open && GetAsyncKeyState(VK_LBUTTON))
				{
					int mouse_x, mouse_y;
					m_inputsys()->GetCursorPosition(&mouse_x, &mouse_y);
					if (mouse_x > x && mouse_y > y && mouse_x < x + 180 && mouse_y < y + 70)
					{
						g_cfg.miscbar_x = mouse_x - 90;
						g_cfg.miscbar_y = mouse_y - 20;
					}
				}
				static IDirect3DTexture9* avatar = nullptr;
				if (!avatar)
				{
					D3DXCreateTextureFromFileInMemoryEx(UI::m_pDevice, &retardsavatar, sizeof(retardsavatar), 32, 32, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, D3DUSAGE_DYNAMIC, NULL, NULL, &avatar);
				}


				std::string weaponnam = g_ctx.globals.weapon->get_name();


				draw->AddRectFilled(ImVec2(x, y), ImVec2(x + 180, y + 27), ImColor(0, 0, 0, 40));

				draw->AddRectFilledMultiColor(ImVec2(x, y), ImVec2(x + 180, y + 2), leftcol, rightcol, rightcol, leftcol);
				//draw->AddRectFilledMultiColor(ImVec2(x + 90, y), ImVec2(x + 180, y + 2), rightcol, leftcol, leftcol, rightcol);

				auto size_font = UI::Font::m_pDefault->CalcTextSizeA(12.f, FLT_MAX, -1.f, "BMS");
				auto size_font_weaponicon = UI::Font::m_pWpnIcon->CalcTextSizeA(26.f, FLT_MAX, -1.f, g_ctx.globals.weapon->get_icon());

				draw->AddText(UI::Font::m_pDefault, 14.f, ImVec2(x + 90 - size_font.x / 2 + 1, y + 8), ImColor(0, 0, 0), "BMS");
				draw->AddText(UI::Font::m_pDefault, 14.f, ImVec2(x + 90 - size_font.x / 2, y + 7), ImColor(255, 255, 255), "BMS");

				draw->AddText(UI::Font::m_pDefault, 12.f, ImVec2(x + 128, y + 31), ImColor(0, 0, 0), ("HTC: " + std::to_string(g_cfg.ragebot.weapon[g_ctx.globals.current_weapon].hitchance_amount)).c_str());
				draw->AddText(UI::Font::m_pDefault, 12.f, ImVec2(x + 127, y + 30), ImColor(255, 255, 255), ("HTC: " + std::to_string(g_cfg.ragebot.weapon[g_ctx.globals.current_weapon].hitchance_amount)).c_str());


				draw->AddText(UI::Font::m_pDefault, 12.f, ImVec2(x + 128, y + 47), ImColor(0, 0, 0), ("DMG: " + std::to_string(g_cfg.ragebot.weapon[g_ctx.globals.current_weapon].minimum_damage)).c_str());
				draw->AddText(UI::Font::m_pDefault, 12.f, ImVec2(x + 127, y + 46), ImColor(255, 255, 255), ("DMG: " + std::to_string(g_cfg.ragebot.weapon[g_ctx.globals.current_weapon].minimum_damage)).c_str());

				//draw->AddImage(avatar, ImVec2(x, y + 27), ImVec2(x + 32, y + 27 + 32));

				draw->AddText(UI::Font::m_pWpnIcon, 26.f, ImVec2(x + 80 - size_font_weaponicon.x / 2 + 1, y + 31), ImColor(0, 0, 0), g_ctx.globals.weapon->get_icon());
				draw->AddText(UI::Font::m_pWpnIcon, 26.f, ImVec2(x + 80 - size_font_weaponicon.x / 2 + 1, y + 30), ImColor(255, 255, 255), g_ctx.globals.weapon->get_icon());

				//draw->AddImageQuad(avatar, ImVec2(x, y + 27), ImVec2(x + 32, y + 27), ImVec2(x, y + 27), ImVec2(x + 32, y + 27 + 32));

				ImGui::End();
			}
			*/
			/*
			if (g_cfg.menu.watermark)
			{
				int x1 = width - 120, y1 = 0;

				draw->AddRectFilledMultiColor(ImVec2(x1 + 5, y1 + 45), ImVec2(x1 + 9, y1 + 35), antiaim_fake_degree_color, antiaim_fake_degree_color, ImColor(0, 0, 0, 20), ImColor(0, 0, 0, 20));
				draw->AddRectFilledMultiColor(ImVec2(x1 + 5, y1 + 45), ImVec2(x1 + 9, y1 + 55), antiaim_fake_degree_color, antiaim_fake_degree_color, ImColor(0, 0, 0, 20), ImColor(0, 0, 0, 20));

				char buf[255];
				sprintf(buf, "%3.1f", antiaim_desync_degree);
				draw->AddTextOutline(UI::Font::m_pDefault, 14.f, ImVec2(x1 + 13, y1 + 37), ImColor(255, 255, 255), (u8"FAKE (" + std::string(buf) + u8"��)").c_str());

				std::string FLtext = "FL:  " + std::to_string(fakelag::get().max_choke);
				draw->AddTextOutline(UI::Font::m_pDefault, 14.f, ImVec2(x1 + 13 + 60, y1 + 37), ImColor(255, 255, 255), FLtext.c_str());

				draw->AddRectFilledMultiColor(ImVec2(x1 + 13 + 60 + ImGui::CalcTextSize(FLtext.c_str()).x / 2, y1 + 37 + ImGui::CalcTextSize(FLtext.c_str()).y), ImVec2(x1 + 13 + 60 + ImGui::CalcTextSize(FLtext.c_str()).x / 2 - 15, y1 + 37 + ImGui::CalcTextSize(FLtext.c_str()).y + 1), ImColor(255, 255, 255), ImColor(255, 255, 255, 20), ImColor(255, 255, 255, 20), ImColor(255, 255, 255));
				draw->AddRectFilledMultiColor(ImVec2(x1 + 13 + 60 + ImGui::CalcTextSize(FLtext.c_str()).x / 2, y1 + 37 + ImGui::CalcTextSize(FLtext.c_str()).y), ImVec2(x1 + 13 + 60 + ImGui::CalcTextSize(FLtext.c_str()).x / 2 + 15, y1 + 37 + ImGui::CalcTextSize(FLtext.c_str()).y + 1), ImColor(255, 255, 255), ImColor(255, 255, 255, 20), ImColor(255, 255, 255, 20), ImColor(255, 255, 255));

				if (m_engine()->IsInGame())
				{
					auto tickrate = std::to_string((int)(1.0f / m_globals()->m_intervalpertick)) + "t";

					sprintf(buf, "%0.2f", m_globals()->m_intervalpertick);
					std::string tickrateinfo = (std::string(buf) + "/" + tickrate);
					draw->AddTextOutline(UI::Font::m_pDefault, 14.f, ImVec2(x1 + 13 + 50, y1 + 60), ImColor(255, 255, 255), tickrateinfo.c_str());
					draw->AddRectFilledMultiColor(ImVec2(x1 + 13 + 50 + ImGui::CalcTextSize(tickrateinfo.c_str()).x / 2, y1 + 60 + ImGui::CalcTextSize(tickrateinfo.c_str()).y), ImVec2(x1 + 13 + 50 + ImGui::CalcTextSize(tickrateinfo.c_str()).x / 2 - 20, y1 + 60 + ImGui::CalcTextSize(tickrateinfo.c_str()).y + 1), ImColor(255, 255, 255), ImColor(255, 255, 255, 20), ImColor(255, 255, 255, 20), ImColor(255, 255, 255));
					draw->AddRectFilledMultiColor(ImVec2(x1 + 13 + 50 + ImGui::CalcTextSize(tickrateinfo.c_str()).x / 2, y1 + 60 + ImGui::CalcTextSize(tickrateinfo.c_str()).y), ImVec2(x1 + 13 + 50 + ImGui::CalcTextSize(tickrateinfo.c_str()).x / 2 + 20, y1 + 60 + ImGui::CalcTextSize(tickrateinfo.c_str()).y + 1), ImColor(255, 255, 255), ImColor(255, 255, 255, 20), ImColor(255, 255, 255, 20), ImColor(255, 255, 255));

				}
			}
			*/
			/*
			if (g_cfg.left_indicator)
			{
				int x = 20, y = height / 2;

				if (m_engine()->IsInGame())
				{
					auto weapon = g_ctx.local()->m_hActiveWeapon().Get();

					if (weapon)
					{
						draw->AddText(UI::Font::m_pDefaultLarge, 32.f, ImVec2(x, y - 70), weapon->can_fire(false) ? ImColor(255, 255, 255, 255) : ImColor(130, 130, 130, 255), "DT");
					}
				}

				float anti_aim_ratio = antiaim_desync_degree / 58.f;

				draw->AddText(UI::Font::m_pDefaultLarge, 32.f, ImVec2(x, y - 30), ImColor(1.f * (1 - anti_aim_ratio), 1.f * anti_aim_ratio, 0.f, 1.f), "FAKE");

				draw->AddText(UI::Font::m_pDefaultLarge, 32.f, ImVec2(x, y + 10), ImColor(255, 255, 255), ("DMG:" + std::to_string(g_cfg.ragebot.weapon[g_ctx.globals.current_weapon].minimum_damage)).c_str());

				draw->AddText(UI::Font::m_pDefaultLarge, 32.f, ImVec2(x, y + 50), ImColor(155, 146, 190), ("FL:" + std::to_string(fakelag::get().max_choke)).c_str());

			}
			*/
		}
	}
	void Draw(bool menu_opened)
	{
		if (menu_opened) //i dont even bother the hooks.cpp vars so
		{
			UI::BeginMainMenu("BaiMaoSense V2");

			static auto type = 0;

			std::string legit_weapons[6] = { crypt_str("Deagle"), crypt_str("Pistols"), crypt_str("Rifles"), crypt_str("SMGs"), crypt_str("Snipers"), crypt_str("Heavy") };
			std::string hitbox_legit[3] = { crypt_str("Nearest"), crypt_str("Head"), crypt_str("Body") };

			static int player = LOCAL;

			static std::vector<std::string> weapon_list;
			static std::vector<std::string> skin_list;
			static std::vector<std::string> glove_skin_list;
			static std::vector<std::string> knife_skin_list;
			static std::vector<std::string> quality_types;
			static bool weapon_list_inited = false;

			switch (UI::Tabs::m_iSelected)
			{
			case 0://rage
				UI::Groupbox::Add(580);
				{
					UI::Item::Checkbox("Enable", &g_cfg.ragebot.enable);

					if (g_cfg.ragebot.enable)
						g_cfg.legitbot.enabled = false;


					UI::Item::SliderInt(crypt_str("Field of view"), 1, 180, &g_cfg.ragebot.field_of_view);
					UI::Item::Checkbox(crypt_str("Silent aim"), &g_cfg.ragebot.silent_aim);
					UI::Item::Checkbox(crypt_str("Automatic wall"), &g_cfg.ragebot.autowall);
					UI::Item::Checkbox(crypt_str("Aimbot with zeus"), &g_cfg.ragebot.zeus_bot);
					UI::Item::Checkbox(crypt_str("Aimbot with knife"), &g_cfg.ragebot.knife_bot);
					UI::Item::Checkbox(crypt_str("Automatic fire"), &g_cfg.ragebot.autoshoot);
					UI::Item::Checkbox(crypt_str("Automatic scope"), &g_cfg.ragebot.autoscope);
					UI::Item::Checkbox(crypt_str("Pitch desync correction"), &g_cfg.ragebot.pitch_antiaim_correction);



					UI::Item::Checkbox(crypt_str("Double tap"), &g_cfg.ragebot.double_tap);

					if (g_cfg.ragebot.double_tap)
					{
						//ImGui::SameLine();
						//UI::Item::Keybind(crypt_str(""), &g_cfg.ragebot.double_tap_key, crypt_str("##HOTKEY_DT"));
						UI::Item::Keybind(crypt_str("Double Tap Key"), (int*)&(g_cfg.ragebot.double_tap_key.key));
						UI::Item::Checkbox(crypt_str("Slow teleport"), &g_cfg.ragebot.slow_teleport);
					}

					UI::Item::Checkbox(crypt_str("Hide shots"), &g_cfg.antiaim.hide_shots);

					if (g_cfg.antiaim.hide_shots)
					{
						//ImGui::SameLine();
						UI::Item::Keybind(crypt_str("Hide Shot Key"), (int*)&g_cfg.antiaim.hide_shots_key.key);
					}
				}
				UI::Groupbox::Add(840, true);
				{
					std::string rage_weapons[8] = { crypt_str("Revolver / Deagle"), crypt_str("Pistols"), crypt_str("SMGs"), crypt_str("Rifles"), crypt_str("SCAR-20/G3SG1"), crypt_str("SSG 08"), crypt_str("AWP"), crypt_str("Heavy") };
					{
						UI::Item::Combo(crypt_str("Current weapon"), &hooks::rage_weapon, rage_weapons, ARRAYSIZE(rage_weapons));

						UI::Item::Combo(crypt_str("Target selection"), &g_cfg.ragebot.weapon[hooks::rage_weapon].selection_type, selection, ARRAYSIZE(selection));

						UI::Item::ComboMulti(crypt_str("Hitboxes"), &g_cfg.ragebot.weapon[hooks::rage_weapon].hitboxes[0], hitboxes, ARRAYSIZE(hitboxes), preview);
						UI::Item::Checkbox(crypt_str("Static point scale"), &g_cfg.ragebot.weapon[hooks::rage_weapon].static_point_scale);

						if (g_cfg.ragebot.weapon[hooks::rage_weapon].static_point_scale)
						{
							UI::Item::SliderFloat(crypt_str("Head multipoint scale"), 0.0f, 100.f, &g_cfg.ragebot.weapon[hooks::rage_weapon].head_scale);
							UI::Item::SliderFloat(crypt_str("Body multipoint scale"), 0.0f, 100.f, &g_cfg.ragebot.weapon[hooks::rage_weapon].body_scale);
						}

						UI::Item::Checkbox(crypt_str("Enable max misses"), &g_cfg.ragebot.weapon[hooks::rage_weapon].max_misses);

						if (g_cfg.ragebot.weapon[hooks::rage_weapon].max_misses)
							UI::Item::SliderInt(crypt_str("Max misses"), 0, 6, &g_cfg.ragebot.weapon[hooks::rage_weapon].max_misses_amount);

						UI::Item::Checkbox(crypt_str("Prefer safe points"), &g_cfg.ragebot.weapon[hooks::rage_weapon].prefer_safe_points);
						UI::Item::Checkbox(crypt_str("Prefer body aim"), &g_cfg.ragebot.weapon[hooks::rage_weapon].prefer_body_aim);

						UI::Item::Keybind(crypt_str("Force safe points"), (int*)&g_cfg.ragebot.safe_point_key.key);
						UI::Item::Keybind(crypt_str("Force body aim"), (int*)&g_cfg.ragebot.body_aim_key.key);

					}
					{
						UI::Item::Checkbox(crypt_str("Automatic stop"), &g_cfg.ragebot.weapon[hooks::rage_weapon].autostop);

						if (g_cfg.ragebot.weapon[hooks::rage_weapon].autostop)
							UI::Item::ComboMulti(crypt_str("Modifiers"), &g_cfg.ragebot.weapon[hooks::rage_weapon].autostop_modifiers[0], autostop_modifiers, ARRAYSIZE(autostop_modifiers), preview);

						UI::Item::Checkbox(crypt_str("Hitchance"), &g_cfg.ragebot.weapon[hooks::rage_weapon].hitchance);

						if (g_cfg.ragebot.weapon[hooks::rage_weapon].hitchance)
							UI::Item::SliderInt(crypt_str("Hitchance amount"), 1, 100, &g_cfg.ragebot.weapon[hooks::rage_weapon].hitchance_amount);

						if (g_cfg.ragebot.double_tap && hooks::rage_weapon <= 4)
						{
							UI::Item::Checkbox(crypt_str("Double tap hitchance"), &g_cfg.ragebot.weapon[hooks::rage_weapon].double_tap_hitchance);

							if (g_cfg.ragebot.weapon[hooks::rage_weapon].double_tap_hitchance)
								UI::Item::SliderInt(crypt_str("Double tap hitchance amount"), 1, 100, &g_cfg.ragebot.weapon[hooks::rage_weapon].double_tap_hitchance_amount);
						}

						UI::Item::SliderInt(crypt_str("Minimum visible damage"), 1, 120, &g_cfg.ragebot.weapon[hooks::rage_weapon].minimum_visible_damage);

						if (g_cfg.ragebot.autowall)
							UI::Item::SliderInt(crypt_str("Minimum wall damage"), 1, 120, &g_cfg.ragebot.weapon[hooks::rage_weapon].minimum_damage);

						UI::Item::Keybind(crypt_str("Damage override"), (int*)&g_cfg.ragebot.weapon[hooks::rage_weapon].damage_override_key.key);

						if (g_cfg.ragebot.weapon[hooks::rage_weapon].damage_override_key.key > KEY_NONE && g_cfg.ragebot.weapon[hooks::rage_weapon].damage_override_key.key < KEY_MAX)
							UI::Item::SliderInt(crypt_str("Minimum override damage"), 1, 120, &g_cfg.ragebot.weapon[hooks::rage_weapon].minimum_override_damage);

					}
				}
				break;
			case 1://antiaim
				UI::Groupbox::Add(130);//+70 +140
				{
					UI::Item::Checkbox(crypt_str("Enable"), &g_cfg.antiaim.enable);
					UI::Item::Combo(crypt_str("Anti-aim type"), &g_cfg.antiaim.antiaim_type, antiaim_type, ARRAYSIZE(antiaim_type));
				}
				UI::Groupbox::Add(730, true);
				{
					if (g_cfg.antiaim.antiaim_type)
					{
						UI::Item::Combo(crypt_str("Desync"), &g_cfg.antiaim.desync, desync, ARRAYSIZE(desync));

						if (g_cfg.antiaim.desync)
						{
							UI::Item::Combo(crypt_str("LBY type"), &g_cfg.antiaim.legit_lby_type, lby_type, ARRAYSIZE(lby_type));

							if (g_cfg.antiaim.desync == 1)
							{
								UI::Item::Keybind(crypt_str("Invert desync"), (int*)&g_cfg.antiaim.flip_desync.key);
							}
						}
					}
					else
					{
						UI::Item::Checkbox(crypt_str("Roll Extend"), &g_cfg.antiaim.desync_extend);
						UI::Item::SliderFloat(crypt_str("Roll Extend Angle"), -45.f, 45.f, &g_cfg.antiaim.desync_extend_angle);
						UI::Item::Combo(crypt_str("Movement type"), &type, movement_type, ARRAYSIZE(movement_type));
						UI::Item::Combo(crypt_str("Pitch"), &g_cfg.antiaim.type[type].pitch, pitch, ARRAYSIZE(pitch));
						UI::Item::Combo(crypt_str("Yaw"), &g_cfg.antiaim.type[type].yaw, yaw, ARRAYSIZE(yaw));
						UI::Item::Combo(crypt_str("Base angle"), &g_cfg.antiaim.type[type].base_angle, baseangle, ARRAYSIZE(baseangle));

						if (g_cfg.antiaim.type[type].yaw)
						{
							UI::Item::SliderInt(g_cfg.antiaim.type[type].yaw == 1 ? crypt_str("Jitter range") : crypt_str("Spin range"), 1, 180, &g_cfg.antiaim.type[type].range);

							if (g_cfg.antiaim.type[type].yaw == 2)
								UI::Item::SliderInt(crypt_str("Spin speed"), 1, 15, &g_cfg.antiaim.type[type].speed);
						}

						UI::Item::Combo(crypt_str("Desync"), &g_cfg.antiaim.type[type].desync, desync, ARRAYSIZE(desync));

						if (g_cfg.antiaim.type[type].desync)
						{
							if (type == ANTIAIM_STAND)
							{
								UI::Item::Combo(crypt_str("LBY type"), &g_cfg.antiaim.lby_type, lby_type, ARRAYSIZE(lby_type));
							}

							if (type != ANTIAIM_STAND || !g_cfg.antiaim.lby_type)
							{
								UI::Item::SliderInt(crypt_str("Desync range"), 1, 60, &g_cfg.antiaim.type[type].desync_range);
								UI::Item::SliderInt(crypt_str("Inverted desync range"), 1, 60, &g_cfg.antiaim.type[type].inverted_desync_range);
								UI::Item::SliderInt(crypt_str("Body lean"), 0, 100, &g_cfg.antiaim.type[type].body_lean);
								UI::Item::SliderInt(crypt_str("Inverted body lean"), 0, 100, &g_cfg.antiaim.type[type].inverted_body_lean);
							}

							if (g_cfg.antiaim.type[type].desync == 1)
							{
								UI::Item::Keybind(crypt_str("Invert desync"), (int*)&g_cfg.antiaim.flip_desync.key);
							}
						}

						UI::Item::Keybind(crypt_str("Manual back"), (int*)&g_cfg.antiaim.manual_back.key);

						UI::Item::Keybind(crypt_str("Manual left"), (int*)&g_cfg.antiaim.manual_left.key);

						UI::Item::Keybind(crypt_str("Manual right"), (int*)&g_cfg.antiaim.manual_right.key);


					}
				}
				UI::Groupbox::Add(500);
				{
					UI::Item::Checkbox(crypt_str("Fake lag"), &g_cfg.antiaim.fakelag);
					if (g_cfg.antiaim.fakelag)
					{
						UI::Item::Combo(crypt_str("Fake lag type"), &g_cfg.antiaim.fakelag_type, fakelags, ARRAYSIZE(fakelags));
						UI::Item::SliderInt(crypt_str("Limit"), 1, 16, &g_cfg.antiaim.fakelag_amount);

						UI::Item::ComboMulti(crypt_str("Fake lag triggers"), &g_cfg.antiaim.fakelag_enablers[0], lagstrigger, ARRAYSIZE(lagstrigger), preview);

						auto enabled_fakelag_triggers = false;

						for (auto i = 0; i < ARRAYSIZE(lagstrigger); i++)
							if (g_cfg.antiaim.fakelag_enablers[i])
								enabled_fakelag_triggers = true;

						if (enabled_fakelag_triggers)
							UI::Item::SliderInt(crypt_str("Triggers limit"), 1, 16, &g_cfg.antiaim.triggers_fakelag_amount);
					}

					if (g_cfg.misc.noduck)
						UI::Item::Keybind(crypt_str("Fake duck"), (int*)&g_cfg.misc.fakeduck_key.key);

					UI::Item::Keybind(crypt_str("Slow walk"), (int*)&g_cfg.misc.slowwalk_key.key);
					UI::Item::Keybind(crypt_str("Auto peek"), (int*)&g_cfg.misc.automatic_peek.key);
				}
				break;
			case 2://legit

				UI::Groupbox::Add(550);
				{
					{
						UI::Item::Checkbox(crypt_str("Enable"), &g_cfg.legitbot.enabled);
						UI::Item::Keybind(crypt_str("Legitbot HotKey"), (int*)&g_cfg.legitbot.key);

						if (g_cfg.legitbot.enabled)
							g_cfg.ragebot.enable = false;

						UI::Item::Checkbox(crypt_str("Friendly fire"), &g_cfg.legitbot.friendly_fire);
						UI::Item::Checkbox(crypt_str("Automatic pistols"), &g_cfg.legitbot.autopistol);

						UI::Item::Checkbox(crypt_str("Automatic scope"), &g_cfg.legitbot.autoscope);

						if (g_cfg.legitbot.autoscope)
							UI::Item::Checkbox(crypt_str("Unscope after shot"), &g_cfg.legitbot.unscope);

						UI::Item::Checkbox(crypt_str("Snipers in zoom only"), &g_cfg.legitbot.sniper_in_zoom_only);

						UI::Item::Checkbox(crypt_str("Enable in air"), &g_cfg.legitbot.do_if_local_in_air);
						UI::Item::Checkbox(crypt_str("Enable if flashed"), &g_cfg.legitbot.do_if_local_flashed);
						UI::Item::Checkbox(crypt_str("Enable in smoke"), &g_cfg.legitbot.do_if_enemy_in_smoke);

						UI::Item::Keybind(crypt_str("Automatic fire key"), (int*)&g_cfg.legitbot.autofire_key.key);
						UI::Item::SliderInt(crypt_str("Automatic fire delay"), 0, 12, &g_cfg.legitbot.autofire_delay);

					}
				}

				UI::Groupbox::Add(690, true);
				{
					UI::Item::Combo(crypt_str("Current weapon"), &hooks::legit_weapon, legit_weapons, ARRAYSIZE(legit_weapons));

					UI::Item::Combo(crypt_str("Hitbox"), &g_cfg.legitbot.weapon[hooks::legit_weapon].priority, hitbox_legit, ARRAYSIZE(hitbox_legit));

					UI::Item::Checkbox(crypt_str("Automatic stop"), &g_cfg.legitbot.weapon[hooks::legit_weapon].auto_stop);

					UI::Item::Combo(crypt_str("Field of view type"), &g_cfg.legitbot.weapon[hooks::legit_weapon].fov_type, LegitFov, ARRAYSIZE(LegitFov));
					UI::Item::SliderFloat(crypt_str("Field of view amount"), 0.f, 30.f, &g_cfg.legitbot.weapon[hooks::legit_weapon].fov);


					UI::Item::SliderFloat(crypt_str("Silent field of view"), 0.f, 30.f, &g_cfg.legitbot.weapon[hooks::legit_weapon].silent_fov); //-V550


					UI::Item::Combo(crypt_str("Smooth type"), &g_cfg.legitbot.weapon[hooks::legit_weapon].smooth_type, LegitSmooth, ARRAYSIZE(LegitSmooth));
					UI::Item::SliderFloat(crypt_str("Smooth amount"), 1.f, 12.f, &g_cfg.legitbot.weapon[hooks::legit_weapon].smooth);


					UI::Item::Combo(crypt_str("RCS type"), &g_cfg.legitbot.weapon[hooks::legit_weapon].rcs_type, RCSType, ARRAYSIZE(RCSType));
					UI::Item::SliderFloat(crypt_str("RCS amount"), 0.f, 100.f, &g_cfg.legitbot.weapon[hooks::legit_weapon].rcs);

					if (g_cfg.legitbot.weapon[hooks::legit_weapon].rcs > 0)
					{
						UI::Item::SliderFloat(crypt_str("RCS custom field of view"), 0.f, 30.f, &g_cfg.legitbot.weapon[hooks::legit_weapon].custom_rcs_fov); //-V550
						UI::Item::SliderFloat(crypt_str("RCS Custom smooth"), 0.f, 12.f, &g_cfg.legitbot.weapon[hooks::legit_weapon].custom_rcs_smooth); //-V550
					}
					UI::Item::SliderInt(crypt_str("Automatic wall damage"), 0, 100, &g_cfg.legitbot.weapon[hooks::legit_weapon].awall_dmg);
					UI::Item::SliderInt(crypt_str("Automatic fire hitchance"), 0, 100, &g_cfg.legitbot.weapon[hooks::legit_weapon].autofire_hitchance);
					UI::Item::SliderFloat(crypt_str("Target switch delay"), 0.f, 1.f, &g_cfg.legitbot.weapon[hooks::legit_weapon].target_switch_delay);
				}
				break;
			case 3://skin
				UI::Groupbox::Add(50);
				{
					UI::Item::Checkbox(crypt_str("Enable"), &g_cfg.skins.enable);
				}
				UI::Groupbox::Add(540, true);
				{
					if (!weapon_list_inited)
					{
						for (int i = 0; i < sizeof(game_data::weapon_names) / sizeof(game_data::weapon_names[0]); ++i)
						{
							weapon_list.push_back(game_data::weapon_names[i].name);
						}
						for (auto& i : SkinChanger::skinKits)
						{
							skin_list.push_back(i.name);
						}
						for (auto& i : SkinChanger::gloveKits)
							glove_skin_list.push_back(i.name);
						for (auto& i : game_data::knife_names)
							knife_skin_list.push_back(i.name);
						for (auto& i : game_data::quality_names)
							quality_types.push_back(i.name);
						weapon_list_inited = true;
					}

					UI::Item::Combo(crypt_str("Weapons"), &g_cfg.skins.selected_weapon, &weapon_list[0], weapon_list.size());
					int cur_definition_index = game_data::weapon_names[g_cfg.skins.selected_weapon].definition_index;
					int cur_index_vector = g_cfg.skins.selected_weapon;


					std::string* Skin_List = &skin_list[0];
					int Skin_List_Length = skin_list.size();
					if (cur_definition_index == GLOVE_T_SIDE)
					{
						Skin_List = &glove_skin_list[0];
						Skin_List_Length = glove_skin_list.size();
					}
					if (cur_definition_index == WEAPON_KNIFE)
					{
						UI::Item::Combo(crypt_str("Knife Type"), &g_cfg.skins.skinChanger[cur_index_vector].definition_override_vector_index, &knife_skin_list[0], knife_skin_list.size());
						
					}
					UI::Item::Combo(crypt_str("Paint Kit"), &g_cfg.skins.skinChanger[cur_index_vector].paint_kit_vector_index, Skin_List, Skin_List_Length, true);

					UI::Item::SliderFloat(crypt_str("Wear"), 0.0, 1.0, &g_cfg.skins.skinChanger[cur_index_vector].wear);
					UI::Item::SliderInt(crypt_str("Seed"), 0, 1000, &g_cfg.skins.skinChanger[cur_index_vector].seed);
					UI::Item::SliderInt(crypt_str("StatTrak"), 0, 1000, &g_cfg.skins.skinChanger[cur_index_vector].stat_trak);
					
					static int quality_index;
					UI::Item::Combo(crypt_str("Quality"), &quality_index, &quality_types[0], quality_types.size());
					g_cfg.skins.skinChanger[cur_index_vector].quality = game_data::quality_names[quality_index].index;

					UI::Item::InputText(crypt_str("CustomName"), &g_cfg.skins.skinChanger[cur_index_vector].custom_name[0], 24);

					if (UI::Item::Button("Update"))
					{
						g_cfg.skins.skinChanger[cur_index_vector].itemIdIndex = g_cfg.skins.selected_weapon;
						if (cur_definition_index != WEAPON_KNIFE)
						{
							g_cfg.skins.skinChanger[cur_index_vector].definition_override_vector_index = g_cfg.skins.selected_weapon;
						}
						g_cfg.skins.skinChanger[cur_index_vector].update();
						SkinChanger::scheduleHudUpdate();
					}

				}
				UI::Groupbox::Add(340);
				{
					UI::Item::Checkbox(crypt_str("Rare animations"), &g_cfg.skins.rare_animations);
					UI::Item::SliderInt(crypt_str("Viewmodel field of view"), 0, 89, &g_cfg.esp.viewmodel_fov);
					UI::Item::SliderInt(crypt_str("Viewmodel X"), -50, 50, &g_cfg.esp.viewmodel_x);
					UI::Item::SliderInt(crypt_str("Viewmodel Y"), -50, 50, &g_cfg.esp.viewmodel_y);
					UI::Item::SliderInt(crypt_str("Viewmodel Z"), -50, 50, &g_cfg.esp.viewmodel_z);
					UI::Item::SliderInt(crypt_str("Viewmodel roll"), -180, 180, &g_cfg.esp.viewmodel_roll);
				}
				break;
			case 4://players
				UI::Groupbox::Add(120);
				{
					UI::Item::Checkbox(crypt_str("Enable"), &g_cfg.player.enable);

					std::string types[3] = { "Enemy","Teammate","Local" };
					UI::Item::Combo("Target", &player, types, 3);
				}
				UI::Groupbox::Add(620, true); //enemy
				{
					UI::Item::Text("Enemy");
					UI::Item::Checkbox(crypt_str("OOF arrows"), &g_cfg.player.arrows);
					UI::Item::ColorPicker(crypt_str(""), g_cfg.player.arrows_color, true);

					if (g_cfg.player.arrows)
					{
						UI::Item::SliderInt(crypt_str("Arrows distance"), 1, 100, &g_cfg.player.distance);
						UI::Item::SliderInt(crypt_str("Arrows size"), 1, 100, &g_cfg.player.size);
					}
					if (g_cfg.ragebot.enable)
					{
						UI::Item::Checkbox(crypt_str("Aimbot points"), &g_cfg.player.show_multi_points);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.show_multi_points_color, true);
					}
					UI::Item::Checkbox(crypt_str("Snap lines"), &g_cfg.player.type[ENEMY].snap_lines);
					UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[ENEMY].snap_lines_color, true);

					UI::Item::Checkbox(crypt_str("Aimbot hitboxes"), &g_cfg.player.lag_hitbox);
					UI::Item::ColorPicker(crypt_str(""), g_cfg.player.lag_hitbox_color, true);

					UI::Item::Checkbox(crypt_str("Bounding box"), &g_cfg.player.type[ENEMY].box);
					UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[ENEMY].box_color, true);

					UI::Item::Checkbox(crypt_str("Name"), &g_cfg.player.type[ENEMY].name);
					UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[ENEMY].name_color, true);

					UI::Item::Checkbox(crypt_str("Health bar"), &g_cfg.player.type[ENEMY].health);
					UI::Item::Checkbox(crypt_str("Health color"), &g_cfg.player.type[ENEMY].custom_health_color);
					UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[ENEMY].health_color, true);

					for (auto i = 0, j = 0; i < ARRAYSIZE(flags); i++)
					{
						if (g_cfg.player.type[ENEMY].flags[i])
						{
							if (j)
								preview += crypt_str(", ") + (std::string)flags[i];
							else
								preview = flags[i];

							j++;
						}
					}

					UI::Item::ComboMulti(crypt_str("Flags"), &g_cfg.player.type[ENEMY].flags[0], flags, ARRAYSIZE(flags), preview);
					UI::Item::ComboMulti(crypt_str("Weapon"), &g_cfg.player.type[ENEMY].weapon[0], weaponplayer, ARRAYSIZE(weaponplayer), preview);


					if (g_cfg.player.type[player].weapon[WEAPON_ICON] || g_cfg.player.type[ENEMY].weapon[WEAPON_TEXT])
					{
						UI::Item::Text(crypt_str("Color "));
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[ENEMY].weapon_color, true);
					}

					UI::Item::Checkbox(crypt_str("Skeleton"), &g_cfg.player.type[ENEMY].skeleton);
					UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[player].skeleton_color, true);

					UI::Item::Checkbox(crypt_str("Ammo bar"), &g_cfg.player.type[ENEMY].ammo);
					UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[ENEMY].ammobar_color, true);

					UI::Item::Checkbox(crypt_str("Footsteps"), &g_cfg.player.type[ENEMY].footsteps);
					UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[ENEMY].footsteps_color, true);

					if (g_cfg.player.type[ENEMY].footsteps)
					{
						UI::Item::SliderInt(crypt_str("Thickness"), 1, 10, &g_cfg.player.type[ENEMY].thickness);
						UI::Item::SliderInt(crypt_str("Radius"), 50, 500, &g_cfg.player.type[ENEMY].radius);
					}

				}
				switch (player)
				{
				case 2: //local
					UI::Groupbox::Add(600); //LOCAL
					{
						UI::Item::Text("Local");
						UI::Item::Combo(crypt_str("Player model T"), &g_cfg.player.player_model_t, player_model_t, ARRAYSIZE(player_model_t));
						UI::Item::Combo(crypt_str("Player model CT"), &g_cfg.player.player_model_ct, player_model_ct, ARRAYSIZE(player_model_ct));

						UI::Item::Checkbox(crypt_str("Snap lines"), &g_cfg.player.type[LOCAL].snap_lines);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[LOCAL].snap_lines_color, true);

						UI::Item::Checkbox(crypt_str("Bounding box"), &g_cfg.player.type[LOCAL].box);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[LOCAL].box_color, true);

						UI::Item::Checkbox(crypt_str("Name"), &g_cfg.player.type[LOCAL].name);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[LOCAL].name_color, true);

						UI::Item::Checkbox(crypt_str("Health bar"), &g_cfg.player.type[LOCAL].health);
						UI::Item::Checkbox(crypt_str("Health color"), &g_cfg.player.type[LOCAL].custom_health_color);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[LOCAL].health_color, true);

						for (auto i = 0, j = 0; i < ARRAYSIZE(flags); i++)
						{
							if (g_cfg.player.type[LOCAL].flags[i])
							{
								if (j)
									preview += crypt_str(", ") + (std::string)flags[i];
								else
									preview = flags[i];

								j++;
							}
						}

						UI::Item::ComboMulti(crypt_str("Flags"), &g_cfg.player.type[LOCAL].flags[0], flags, ARRAYSIZE(flags), preview);
						UI::Item::ComboMulti(crypt_str("Weapon"), &g_cfg.player.type[LOCAL].weapon[0], weaponplayer, ARRAYSIZE(weaponplayer), preview);


						if (g_cfg.player.type[player].weapon[WEAPON_ICON] || g_cfg.player.type[LOCAL].weapon[WEAPON_TEXT])
						{
							UI::Item::Text(crypt_str("Color "));
							UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[LOCAL].weapon_color, true);
						}

						UI::Item::Checkbox(crypt_str("Skeleton"), &g_cfg.player.type[LOCAL].skeleton);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[player].skeleton_color, true);

						UI::Item::Checkbox(crypt_str("Ammo bar"), &g_cfg.player.type[LOCAL].ammo);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[LOCAL].ammobar_color, true);

						UI::Item::Checkbox(crypt_str("Footsteps"), &g_cfg.player.type[LOCAL].footsteps);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[LOCAL].footsteps_color, true);

						if (g_cfg.player.type[LOCAL].footsteps)
						{
							UI::Item::SliderInt(crypt_str("Thickness"), 1, 10, &g_cfg.player.type[LOCAL].thickness);
							UI::Item::SliderInt(crypt_str("Radius"), 50, 500, &g_cfg.player.type[LOCAL].radius);
						}
					}
					break;
				case 1:
					UI::Groupbox::Add(540); //teammate
					{
						UI::Item::Text("Teammate");

						UI::Item::Checkbox(crypt_str("Snap lines"), &g_cfg.player.type[TEAM].snap_lines);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[TEAM].snap_lines_color, true);

						UI::Item::Checkbox(crypt_str("Bounding box"), &g_cfg.player.type[TEAM].box);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[TEAM].box_color, true);

						UI::Item::Checkbox(crypt_str("Name"), &g_cfg.player.type[TEAM].name);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[TEAM].name_color, true);

						UI::Item::Checkbox(crypt_str("Health bar"), &g_cfg.player.type[TEAM].health);
						UI::Item::Checkbox(crypt_str("Health color"), &g_cfg.player.type[TEAM].custom_health_color);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[TEAM].health_color, true);

						for (auto i = 0, j = 0; i < ARRAYSIZE(flags); i++)
						{
							if (g_cfg.player.type[TEAM].flags[i])
							{
								if (j)
									preview += crypt_str(", ") + (std::string)flags[i];
								else
									preview = flags[i];

								j++;
							}
						}

						UI::Item::ComboMulti(crypt_str("Flags"), &g_cfg.player.type[TEAM].flags[0], flags, ARRAYSIZE(flags), preview);
						UI::Item::ComboMulti(crypt_str("Weapon"), &g_cfg.player.type[TEAM].weapon[0], weaponplayer, ARRAYSIZE(weaponplayer), preview);


						if (g_cfg.player.type[player].weapon[WEAPON_ICON] || g_cfg.player.type[TEAM].weapon[WEAPON_TEXT])
						{
							UI::Item::Text(crypt_str("Color "));
							UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[TEAM].weapon_color, true);
						}

						UI::Item::Checkbox(crypt_str("Skeleton"), &g_cfg.player.type[TEAM].skeleton);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[player].skeleton_color, true);

						UI::Item::Checkbox(crypt_str("Ammo bar"), &g_cfg.player.type[TEAM].ammo);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[TEAM].ammobar_color, true);

						UI::Item::Checkbox(crypt_str("Footsteps"), &g_cfg.player.type[TEAM].footsteps);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[TEAM].footsteps_color, true);

						if (g_cfg.player.type[TEAM].footsteps)
						{
							UI::Item::SliderInt(crypt_str("Thickness"), 1, 10, &g_cfg.player.type[TEAM].thickness);
							UI::Item::SliderInt(crypt_str("Radius"), 50, 500, &g_cfg.player.type[TEAM].radius);
						}
					}
					break;
				}
				UI::Groupbox::Add(740, true);
				{
					if (player == LOCAL)
						UI::Item::Combo(crypt_str("Type"), &g_cfg.player.local_chams_type, local_chams_type, ARRAYSIZE(local_chams_type));

					if (player != LOCAL || !g_cfg.player.local_chams_type)
						UI::Item::Combo(crypt_str("Chams"), &g_cfg.player.type[player].chams[0], g_cfg.player.type[player].chams[PLAYER_CHAMS_VISIBLE] ? chamsvisact : chamsvis, &g_cfg.player.type[player].chams[PLAYER_CHAMS_VISIBLE] ? ARRAYSIZE(chamsvisact) : ARRAYSIZE(chamsvis));

					if (g_cfg.player.type[player].chams[PLAYER_CHAMS_VISIBLE] || player == LOCAL && g_cfg.player.local_chams_type) //-V648
					{
						if (player == LOCAL && g_cfg.player.local_chams_type)
						{
							UI::Item::Checkbox(crypt_str("Enable desync chams"), &g_cfg.player.fake_chams_enable);
							UI::Item::Checkbox(crypt_str("Visualize lag"), &g_cfg.player.visualize_lag);
							UI::Item::Checkbox(crypt_str("Layered"), &g_cfg.player.layered);

							UI::Item::Combo(crypt_str("Player chams material"), &g_cfg.player.fake_chams_type, chamstype, ARRAYSIZE(chamstype));

							UI::Item::Text(crypt_str("Color "));
							UI::Item::ColorPicker(crypt_str(""), g_cfg.player.fake_chams_color, true);

							if (g_cfg.player.fake_chams_type != 6)
							{
								UI::Item::Checkbox(crypt_str("Double material "), &g_cfg.player.fake_double_material);
								UI::Item::ColorPicker(crypt_str(""), g_cfg.player.fake_double_material_color, true);
							}

							UI::Item::Checkbox(crypt_str("Animated material"), &g_cfg.player.fake_animated_material);
							UI::Item::ColorPicker(crypt_str(""), g_cfg.player.fake_animated_material_color, true);
						}
						else
						{
							UI::Item::Combo(crypt_str("Player chams material"), &g_cfg.player.type[player].chams_type, chamstype, ARRAYSIZE(chamstype));

							if (g_cfg.player.type[player].chams[PLAYER_CHAMS_VISIBLE])
							{
								UI::Item::Text(crypt_str("Visible "));
								UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[player].chams_color, true);
							}

							if (g_cfg.player.type[player].chams[PLAYER_CHAMS_VISIBLE] && g_cfg.player.type[player].chams[PLAYER_CHAMS_INVISIBLE])
							{
								UI::Item::Text(crypt_str("Invisible "));
								UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[player].xqz_color, true);
							}

							if (g_cfg.player.type[player].chams_type != 6)
							{
								UI::Item::Checkbox(crypt_str("Double material "), &g_cfg.player.type[player].double_material);
								UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[player].double_material_color, true);
							}

							UI::Item::Checkbox(crypt_str("Animated material"), &g_cfg.player.type[player].animated_material);
							UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[player].animated_material_color, true);

							if (player == ENEMY)
							{
								UI::Item::Checkbox(crypt_str("Backtrack chams"), &g_cfg.player.backtrack_chams);

								if (g_cfg.player.backtrack_chams)
								{
									UI::Item::Combo(crypt_str("Backtrack chams material"), &g_cfg.player.backtrack_chams_material, chamstype, ARRAYSIZE(chamstype));

									UI::Item::ColorPicker(crypt_str("Color"), g_cfg.player.backtrack_chams_color, true);
								}
							}
						}
					}

					if (player == ENEMY || player == TEAM)
					{
						UI::Item::Checkbox(crypt_str("Ragdoll chams"), &g_cfg.player.type[player].ragdoll_chams);

						if (g_cfg.player.type[player].ragdoll_chams)
						{
							UI::Item::Combo(crypt_str("Ragdoll chams material"), &g_cfg.player.type[player].ragdoll_chams_material, chamstype, ARRAYSIZE(chamstype));

							UI::Item::Text(crypt_str("Color "));
							UI::Item::ColorPicker(crypt_str(""), g_cfg.player.type[player].ragdoll_chams_color, true);
						}
					}
					else if (!g_cfg.player.local_chams_type)
					{
						UI::Item::Checkbox(crypt_str("Transparency in scope"), &g_cfg.player.transparency_in_scope);

						if (g_cfg.player.transparency_in_scope)
							UI::Item::SliderFloat(crypt_str("Alpha"), 0.0f, 1.0f, &g_cfg.player.transparency_in_scope_amount);
					}

					UI::Item::Checkbox(crypt_str("Glow"), &g_cfg.player.type[player].glow);

					if (g_cfg.player.type[player].glow)
					{
						UI::Item::Combo(crypt_str("Glow type"), &g_cfg.player.type[player].glow_type, glowtype, ARRAYSIZE(glowtype));
						UI::Item::ColorPicker(crypt_str("Color"), g_cfg.player.type[player].glow_color, true);
					}
				}
				UI::Groupbox::Add(540);
				{
					{
						UI::Item::Checkbox(crypt_str("Arms chams"), &g_cfg.esp.arms_chams);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.arms_chams_color, true);


						UI::Item::Combo(crypt_str("Arms chams material"), &g_cfg.esp.arms_chams_type, chamstype, ARRAYSIZE(chamstype));

						if (g_cfg.esp.arms_chams_type != 6)
						{
							UI::Item::Checkbox(crypt_str("Arms double material "), &g_cfg.esp.arms_double_material);
							UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.arms_double_material_color, true);
						}

						UI::Item::Checkbox(crypt_str("Arms animated material "), &g_cfg.esp.arms_animated_material);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.arms_animated_material_color, true);

						UI::Item::Checkbox(crypt_str("Weapon chams"), &g_cfg.esp.weapon_chams);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.weapon_chams_color, true);

						UI::Item::Combo(crypt_str("Weapon chams material"), &g_cfg.esp.weapon_chams_type, chamstype, ARRAYSIZE(chamstype));

						if (g_cfg.esp.weapon_chams_type != 6)
						{
							UI::Item::Checkbox(crypt_str("Double material "), &g_cfg.esp.weapon_double_material);
							UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.weapon_double_material_color, true);
						}

						UI::Item::Checkbox(crypt_str("Animated material "), &g_cfg.esp.weapon_animated_material);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.weapon_animated_material_color, true);

					}
				}
				UI::Groupbox::Add(1100, true);
				{
					{
						UI::Item::ComboMulti(crypt_str("Removals"), &g_cfg.esp.removals[0], removals, ARRAYSIZE(removals), preview);

						if (g_cfg.esp.removals[REMOVALS_ZOOM])
							UI::Item::Checkbox(crypt_str("Fix zoom sensivity"), &g_cfg.esp.fix_zoom_sensivity);

						UI::Item::Checkbox(crypt_str("Grenade prediction"), &g_cfg.esp.grenade_prediction);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.grenade_prediction_color, true);

						if (g_cfg.esp.grenade_prediction)
						{
							UI::Item::Checkbox(crypt_str("On click"), &g_cfg.esp.on_click);
							UI::Item::Text(crypt_str("Tracer color "));
							UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.grenade_prediction_tracer_color, true);
						}

						UI::Item::Checkbox(crypt_str("Grenade projectiles"), &g_cfg.esp.projectiles);

						if (g_cfg.esp.projectiles)
							UI::Item::ComboMulti(crypt_str("Grenade ESP"), &g_cfg.esp.grenade_esp[0], proj_combo, ARRAYSIZE(proj_combo), preview);

						if (g_cfg.esp.grenade_esp[GRENADE_ICON] || g_cfg.esp.grenade_esp[GRENADE_TEXT])
						{
							UI::Item::Text(crypt_str("Color "));
							UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.projectiles_color, true);
						}

						if (g_cfg.esp.grenade_esp[GRENADE_BOX])
						{
							UI::Item::Text(crypt_str("Box color "));
							UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.grenade_box_color, true);
						}

						if (g_cfg.esp.grenade_esp[GRENADE_GLOW])
						{
							UI::Item::Text(crypt_str("Glow color "));
							UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.grenade_glow_color, true);
						}

						UI::Item::Checkbox(crypt_str("Fire timer"), &g_cfg.esp.molotov_timer);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.molotov_timer_color, true);

						UI::Item::Checkbox(crypt_str("Smoke timer"), &g_cfg.esp.smoke_timer);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.smoke_timer_color, true);

						UI::Item::Checkbox(crypt_str("Bomb indicator"), &g_cfg.esp.bomb_timer);
						UI::Item::ComboMulti(crypt_str("Weapon ESP"), &g_cfg.esp.weapon[0], weaponesp, ARRAYSIZE(weaponesp), preview);

						if (g_cfg.esp.weapon[WEAPON_ICON] || g_cfg.esp.weapon[WEAPON_TEXT] || g_cfg.esp.weapon[WEAPON_DISTANCE])
						{
							UI::Item::Text(crypt_str("Color "));
							UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.weapon_color, true);
						}

						if (g_cfg.esp.weapon[WEAPON_BOX])
						{
							UI::Item::Text(crypt_str("Box color "));
							UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.box_color, true);
						}

						if (g_cfg.esp.weapon[WEAPON_GLOW])
						{
							UI::Item::Text(crypt_str("Glow color "));
							UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.weapon_glow_color, true);
						}

						if (g_cfg.esp.weapon[WEAPON_AMMO])
						{
							UI::Item::Text(crypt_str("Ammo bar color "));
							UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.weapon_ammo_color, true);
						}

						UI::Item::Checkbox(crypt_str("Client bullet impacts"), &g_cfg.esp.client_bullet_impacts);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.client_bullet_impacts_color, true);

						UI::Item::Checkbox(crypt_str("Server bullet impacts"), &g_cfg.esp.server_bullet_impacts);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.server_bullet_impacts_color, true);

						UI::Item::Checkbox(crypt_str("Local bullet tracers"), &g_cfg.esp.bullet_tracer);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.bullet_tracer_color, true);

						UI::Item::Checkbox(crypt_str("Enemy bullet tracers"), &g_cfg.esp.enemy_bullet_tracer);

						UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.enemy_bullet_tracer_color, true);

						UI::Item::ComboMulti(crypt_str("Hit marker"), &g_cfg.esp.hitmarker[0], hitmarkers, ARRAYSIZE(hitmarkers), preview);

						UI::Item::Checkbox(crypt_str("Damage marker"), &g_cfg.esp.damage_marker);
						UI::Item::Checkbox(crypt_str("Kill effect"), &g_cfg.esp.kill_effect);

						if (g_cfg.esp.kill_effect)
							UI::Item::SliderFloat(crypt_str("Duration"), 0.01f, 3.0f, &g_cfg.esp.kill_effect_duration);

						UI::Item::Keybind(crypt_str("Thirdperson"), (int*)&g_cfg.misc.thirdperson_toggle.key);

						UI::Item::Checkbox(crypt_str("Thirdperson when spectating"), &g_cfg.misc.thirdperson_when_spectating);

						if (g_cfg.misc.thirdperson_toggle.key > KEY_NONE && g_cfg.misc.thirdperson_toggle.key < KEY_MAX)
							UI::Item::SliderInt(crypt_str("Thirdperson distance"), 100, 300, &g_cfg.misc.thirdperson_distance);

						UI::Item::SliderInt(crypt_str("Field of view"), 0, 89, &g_cfg.esp.fov);
						UI::Item::Checkbox(crypt_str("Taser range"), &g_cfg.esp.taser_range);
						UI::Item::Checkbox(crypt_str("Show spread"), &g_cfg.esp.show_spread);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.show_spread_color, true);
						UI::Item::Checkbox(crypt_str("Penetration crosshair"), &g_cfg.esp.penetration_reticle);
					}
				}
				break;
			case 5://indicators aka visuals
				/*
				UI::Groupbox::Add(340);
				{
					UI::Item::Text("Ragebot/Anti-Aim");
					UI::Item::Checkbox("Indicator", &g_cfg.ragebot.indicator);
					UI::Item::SliderInt(crypt_str("Indicator X"), 1, 1920, &g_cfg.miscbar_x);
					UI::Item::SliderInt(crypt_str("Indicator Y"), 1, 1080, &g_cfg.miscbar_y);

					UI::Item::Checkbox("AntiAim Indicator", &g_cfg.antiaim.antiaim_indicator);
					UI::Item::SliderInt("AntiAim Indicator x", 0, 1920, &g_cfg.antiaim.antiaim_indicator_x);
					UI::Item::SliderInt("AntiAim Indicator y", 0, 1080, &g_cfg.antiaim.antiaim_indicator_y);

					if (g_cfg.antiaim.manual_back.key > KEY_NONE && g_cfg.antiaim.manual_back.key < KEY_MAX || g_cfg.antiaim.manual_left.key > KEY_NONE && g_cfg.antiaim.manual_left.key < KEY_MAX || g_cfg.antiaim.manual_right.key > KEY_NONE && g_cfg.antiaim.manual_right.key < KEY_MAX)
					{
						UI::Item::Checkbox(crypt_str("Manuals indicator"), &g_cfg.antiaim.flip_indicator);
						UI::Item::ColorPicker(crypt_str(""), g_cfg.antiaim.flip_indicator_color, true);
					}
					
				}
				*/
				UI::Groupbox::Add(540);
				{
					UI::Item::Text("Misc");

					UI::Item::Checkbox(crypt_str("Watermark"), &g_cfg.menu.watermark);
					UI::Item::Checkbox(crypt_str("Spectators list"), &g_cfg.misc.spectators_list);
					UI::Item::SliderInt(crypt_str("Spectators X"), 1, 1920, &g_cfg.misc_spec_x);
					UI::Item::SliderInt(crypt_str("Spectators Y"), 1, 1080, &g_cfg.misc_spec_y);
					UI::Item::Checkbox(crypt_str("Keybinds"), &g_cfg.keybind_indicator);
					UI::Item::SliderInt(crypt_str("Keybinds X"), 1, 1920, &g_cfg.keybind_indicator_x);
					UI::Item::SliderInt(crypt_str("Keybinds Y"), 1, 1080, &g_cfg.keybind_indicator_y);

					UI::Item::ComboMulti(crypt_str("Indicators"), &g_cfg.esp.indicators[0], indicators, ARRAYSIZE(indicators), preview);

					UI::Item::Checkbox(crypt_str("Custom Indicator Color"), &g_cfg.custom_indicator_col);

					UI::Item::ColorPicker(crypt_str("Indicator Color:"), g_cfg.indicator_col.Value, true);

					UI::Item::Checkbox(crypt_str("Left Indicator"), &g_cfg.left_indicator);
				}
				UI::Groupbox::Add(220);
				{
					if (UI::Item::Button(crypt_str("Inverted Theme")))
					{
						ImU32* m_pColors[] =
						{
							&UI::Colors::m_iText, &UI::Colors::m_iTextAlt,
							&UI::Colors::m_iMenuBG, &UI::Colors::m_iMenuAltBG, &UI::Colors::m_iPopupBG,
							&UI::Colors::m_iItem0, &UI::Colors::m_iMenuLeftBG
						};

						for (ImU32* m_pColor : m_pColors)
						{
							unsigned char* m_pColorBytes = reinterpret_cast<unsigned char*>(m_pColor);

							for (int i = 0; 3 > i; ++i)
								m_pColorBytes[i] = 255 - m_pColorBytes[i];
						}
					}
					UI::Item::Checkbox("Short Menu", &UI::Tabs::m_bShortMode);

					UI::Item::ColorPicker("Text Color", UI::Colors::m_iText, true);
					UI::Item::ColorPicker("Alt-Text Color", UI::Colors::m_iTextAlt, true);
					UI::Item::ColorPicker("Menu Background Color", UI::Colors::m_iMenuBG, true);
					UI::Item::ColorPicker("Menu Left Background Color", UI::Colors::m_iMenuLeftBG, true);
					UI::Item::ColorPicker("Menu Alt-Background  Color", UI::Colors::m_iMenuAltBG, true);
					UI::Item::ColorPicker("Popup Background Color", UI::Colors::m_iPopupBG, true);
					UI::Item::ColorPicker("Menu Items Color", UI::Colors::m_iItem0, true);
				}
				UI::Groupbox::Add(600, true);
				{
					//UI::Item::Checkbox(crypt_str("Rain"), &g_cfg.esp.rain);
					UI::Item::Checkbox(crypt_str("Full bright"), &g_cfg.esp.bright);

					UI::Item::Combo(crypt_str("Skybox"), &g_cfg.esp.skybox, skybox, ARRAYSIZE(skybox));

					UI::Item::Text(crypt_str("Color "));
					UI::Item::ColorPicker(crypt_str(""), g_cfg.esp.skybox_color);

					if (g_cfg.esp.skybox == 21)
					{
						static char sky_custom[64] = "\0";

						if (!g_cfg.esp.custom_skybox.empty())
							strcpy_s(sky_custom, sizeof(sky_custom), g_cfg.esp.custom_skybox.c_str());

						UI::Item::Text(crypt_str("Name"));

						UI::Item::InputText(crypt_str("Customsky"), sky_custom, sizeof(sky_custom));
						g_cfg.esp.custom_skybox = sky_custom;

					}

					UI::Item::Checkbox(crypt_str("Color modulation"), &g_cfg.esp.nightmode);

					if (g_cfg.esp.nightmode)
					{
						UI::Item::Text(crypt_str("World color "));
						ImGui::SameLine();
						UI::Item::ColorPicker(crypt_str("##worldcolor"), g_cfg.esp.world_color, true);

						UI::Item::Text(crypt_str("Props color "));
						ImGui::SameLine();
						UI::Item::ColorPicker(crypt_str("##propscolor"), g_cfg.esp.props_color, true);
					}

					UI::Item::Checkbox(crypt_str("World modulation"), &g_cfg.esp.world_modulation);

					if (g_cfg.esp.world_modulation)
					{
						UI::Item::SliderFloat(crypt_str("Bloom"), 0.0f, 750.0f, &g_cfg.esp.bloom);
						UI::Item::SliderFloat(crypt_str("Exposure"), 0.0f, 2000.0f, &g_cfg.esp.exposure);
						UI::Item::SliderFloat(crypt_str("Ambient"), 0.0f, 1500.0f, &g_cfg.esp.ambient);
					}

					UI::Item::Checkbox(crypt_str("Fog modulation"), &g_cfg.esp.fog);

					if (g_cfg.esp.fog)
					{
						UI::Item::SliderInt(crypt_str("Distance"), 0, 2500, &g_cfg.esp.fog_distance);
						UI::Item::SliderInt(crypt_str("Density"), 0, 100, &g_cfg.esp.fog_density);

						UI::Item::Text(crypt_str("Color "));
						UI::Item::ColorPicker(crypt_str("fogcolor"), g_cfg.esp.fog_color);
					}
				}
				break;
			case 6://misc
				UI::Groupbox::Add(50);
				{
					UI::Item::Checkbox(crypt_str("Enable"), &g_cfg.player.enable);
				}
				UI::Groupbox::Add(800, true);
				{
					{
						UI::Item::Checkbox(crypt_str("Automatic jump"), &g_cfg.misc.bunnyhop);
						UI::Item::Combo(crypt_str("Automatic strafes"), &g_cfg.misc.airstrafe, strafes, ARRAYSIZE(strafes));
						UI::Item::Checkbox(crypt_str("Crouch in air"), &g_cfg.misc.crouch_in_air);
						UI::Item::Checkbox(crypt_str("Fast stop"), &g_cfg.misc.fast_stop);
						UI::Item::Checkbox(crypt_str("Slide walk"), &g_cfg.misc.slidewalk);
						UI::Item::Checkbox(crypt_str("No duck cooldown"), &g_cfg.misc.noduck);

						UI::Item::Keybind(crypt_str("Edge jump"), (int*)&g_cfg.misc.edge_jump.key);

						UI::Item::Checkbox(crypt_str("Anti-untrusted"), &g_cfg.misc.anti_untrusted);
						UI::Item::Checkbox(crypt_str("Rank reveal"), &g_cfg.misc.rank_reveal);
						UI::Item::Checkbox(crypt_str("Unlock inventory access"), &g_cfg.misc.inventory_access);
						UI::Item::Checkbox(crypt_str("Gravity ragdolls"), &g_cfg.misc.ragdolls);
						UI::Item::Checkbox(crypt_str("Preserve killfeed"), &g_cfg.esp.preserve_killfeed);
						UI::Item::Checkbox(crypt_str("Aspect ratio"), &g_cfg.misc.aspect_ratio);

						if (g_cfg.misc.aspect_ratio)
						{
							UI::Item::SliderFloat(crypt_str("Amount"), 1.0f, 2.0f, &g_cfg.misc.aspect_ratio_amount);
						}

					}

				}
				UI::Groupbox::Add(590);
				{
					{
						UI::Item::Combo(crypt_str("Hitsound"), &g_cfg.esp.hitsound, sounds, ARRAYSIZE(sounds));
						UI::Item::Checkbox(crypt_str("Killsound"), &g_cfg.esp.killsound);
						UI::Item::ComboMulti(crypt_str("Logs"), &g_cfg.misc.events_to_log[0], events, ARRAYSIZE(events), preview);
						UI::Item::ComboMulti(crypt_str("Logs output"), &g_cfg.misc.log_output[0], events_output, ARRAYSIZE(events_output), preview);

						if (g_cfg.misc.events_to_log[EVENTLOG_HIT] || g_cfg.misc.events_to_log[EVENTLOG_ITEM_PURCHASES] || g_cfg.misc.events_to_log[EVENTLOG_BOMB] || g_cfg.misc.events_to_log[EVENTLOG_MISSED_SHOT])
						{
							UI::Item::Text(crypt_str("Color "));
							UI::Item::ColorPicker(crypt_str(""), g_cfg.misc.log_color, true);
						}

						//UI::Item::Checkbox(crypt_str("Show CS:GO logs"), &g_cfg.misc.show_default_log);

						//UI::Item::Checkbox(crypt_str("Anti-screenshot"), &g_cfg.misc.anti_screenshot);
						UI::Item::Checkbox(crypt_str("Clantag"), &g_cfg.misc.clantag_spammer);
						//UI::Item::Checkbox(crypt_str("Chat spam"), &g_cfg.misc.chat);
						UI::Item::Checkbox(crypt_str("Enable buybot"), &g_cfg.misc.buybot_enable);

						if (g_cfg.misc.buybot_enable)
						{
							UI::Item::Combo(crypt_str("Snipers"), &g_cfg.misc.buybot1, mainwep, ARRAYSIZE(mainwep));
							UI::Item::Combo(crypt_str("Pistols"), &g_cfg.misc.buybot2, secwep, ARRAYSIZE(secwep));
							UI::Item::ComboMulti(crypt_str("Other"), &g_cfg.misc.buybot3[0], grenades, ARRAYSIZE(grenades), preview);
						}

					}
				}
				break;
			case 7: //script
				if (should_update_lua)
				{
					c_lua::get().refresh_scripts();
					scripts = c_lua::get().scripts;

					if (selected_script >= scripts.size())
						selected_script = scripts.size() - 1; //-V103

					for (auto& current : scripts)
					{
						if (current.size() >= 5 && current.at(current.size() - 1) == 'c')
							current.erase(current.size() - 5, 5);
						else if (current.size() >= 4)
							current.erase(current.size() - 4, 4);
					}
					should_update_lua = false;
				}
				switch (UI::Scriptbox::Top())
				{
				case 1://refresh
					c_lua::get().refresh_scripts();
					scripts = c_lua::get().scripts;

					if (selected_script >= scripts.size())
						selected_script = scripts.size() - 1; //-V103

					for (auto& current : scripts)
					{
						if (current.size() >= 5 && current.at(current.size() - 1) == 'c')
							current.erase(current.size() - 5, 5);
						else if (current.size() >= 4)
							current.erase(current.size() - 4, 4);
					}
					break;
				case 2:
					WCHAR path[MAX_PATH];
					if (SUCCEEDED(SHGetFolderPathW(NULL, CSIDL_APPDATA, NULL, NULL, path)))
					{
						auto folder = std::wstring(path) + crypt_str(L"\\BaiMaoSense\\Scripts");
						CreateDirectoryW(folder.c_str(), NULL);
						PIDLIST_ABSOLUTE pidl;
						if (SUCCEEDED(SHParseDisplayName(folder.c_str(), 0, &pidl, 0, 0)))
						{
							ITEMIDLIST idNull = { 0 };
							LPCITEMIDLIST pidlNull[1] = { &idNull };
							SHOpenFolderAndSelectItems(pidl, 1, pidlNull, 0);
							ILFree(pidl);
						}
					}
					break;
				}
				for (auto& script : scripts)
				{
					auto script_id = c_lua::get().get_script_id(script + crypt_str(".lua"));

					if (script_id == -1)
						continue;

					switch (UI::Scriptbox::Add(scripts.at(script_id), "Unknown", "User", c_lua::get().loaded.at(script_id)))
					{
					case 1:	//Load
						c_lua::get().load_script(script_id);
						c_lua::get().refresh_scripts();

						scripts = c_lua::get().scripts;

						if (selected_script >= scripts.size())
							selected_script = scripts.size() - 1; //-V103

						for (auto& current : scripts)
						{
							if (current.size() >= 5 && current.at(current.size() - 1) == 'c')
								current.erase(current.size() - 5, 5);
							else if (current.size() >= 4)
								current.erase(current.size() - 4, 4);
						}

						eventlogs::get().add(crypt_str("Loaded ") + scripts.at(script_id) + crypt_str(" script"), false); //-V106

						break;
					case 2: //unload
						c_lua::get().unload_script(script_id);
						c_lua::get().refresh_scripts();

						scripts = c_lua::get().scripts;

						if (selected_script >= scripts.size())
							selected_script = scripts.size() - 1; //-V103

						for (auto& current : scripts)
						{
							if (current.size() >= 5 && current.at(current.size() - 1) == 'c')
								current.erase(current.size() - 5, 5);
							else if (current.size() >= 4)
								current.erase(current.size() - 4, 4);
						}

						eventlogs::get().add(crypt_str("Unloaded ") + scripts.at(script_id) + crypt_str(" script"), false); //-V106
						break;
					}
				}
				break;
			case 8: //lua items

				for (int i = 0; i < c_lua::get().items.size(); i++)
				{
					bool RightSide = false;
					if (i % 2)
						RightSide = true;

					auto& item = c_lua::get().items[i];
					if (item.size() <= 0)
						continue;
					
					int ElementsHigh = 40 + item.size() * 50;
					UI::Groupbox::Add(ElementsHigh, RightSide);
					{
						for (auto& n : item)
						{
							switch (n.second.type)
							{
							case CHECK_BOX:
								UI::Item::Checkbox(n.first, &n.second.check_box_value);
								break;
							case NEXT_LINE:
								UI::Item::Text(" - ");
								break;
							case COMBO_BOX:
								UI::Item::Combo(n.first, &n.second.combo_box_value, &n.second.combo_box_labels[0], n.second.combo_box_labels.size());
								break;
							case SLIDER_INT:
								UI::Item::SliderInt(n.first, n.second.slider_int_min, n.second.slider_int_max, &n.second.slider_int_value);
								break;
							case SLIDER_FLOAT:
								UI::Item::SliderFloat(n.first, n.second.slider_float_min, n.second.slider_float_max, &n.second.slider_float_value);
								break;
							case COLOR_PICKER:
								UI::Item::ColorPicker(n.first, n.second.color_picker_value, true);
								break;
							}
						}
					}
				}


				break;
			case 9:	//config -----------------------------------------------------------------------------------------------------------------------------------

				switch (UI::Configbox::Top(cName, sizeof(cName)))
				{
				case 1://save
					save_config();
					break;
				case 2://create
					g_cfg.new_config_name = cName;
					add_config();
					break;
				case 3://refresh
					cfg_manager->config_files();
					files = cfg_manager->files;

					for (auto& current : files)
					{
						if (current.size() > 2)
							current.erase(current.size() - 4, 4);
					}
					break;
				case 4://load from clipboard

					std::string cfg;
					clip::get_text(cfg);
					cfg_manager->import1(cfg);

					break;
				}

				if (should_update)
				{
					should_update = false;

					cfg_manager->config_files();

					files = cfg_manager->files;

					for (auto& current : files)
						if (current.size() > 2)
							current.erase(current.size() - 4, 4);
				}


				for (int i = 0; i < files.size(); i++)
				{
					std::string cfg;
					switch (UI::Configbox::Add(files[i], "Unknown", cfg_manager->filesAuthor[i].c_str(), g_cfg.selected_config == i))
					{
					case 1:	//Load
						g_cfg.is_loading_cfg = true;
						g_cfg.selected_config = i;
						load_config();
						g_cfg.is_loading_cfg = false;
						break;
					case 2:	//Delete
						g_cfg.selected_config = i;
						remove_config();
						g_cfg.selected_config = -1;
						break;
					case 3: //export
						g_cfg.selected_config = i;
						cfg = cfg_manager->export1(cfg_manager->files.at(g_cfg.selected_config));
						clip::set_text(cfg);
						break;
					case 4: //save
						save_config();
						break;
					}
				}

				break;
			default:
				break;
			}
			UI::EndMainMenu();
		}
	}

	LRESULT WndProcHandle(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
	{
		if (ImGui::GetCurrentContext() == NULL) return false;

		ImGuiIO& io = ImGui::GetIO();
		static POINTS m;
		UI::WndProcHandle(hWnd, uMsg, wParam, lParam);
		switch (uMsg)
		{
		case WM_LBUTTONDOWN:
			io.MouseDown[0] = true;
			SetCapture(UI::m_hWindow);
			m = MAKEPOINTS(lParam);
			return true;
		case WM_LBUTTONUP:
			ReleaseCapture();
			io.MouseDown[0] = false;
			return true;
		case WM_RBUTTONDOWN:
			io.MouseDown[1] = true;
			return true;
		case WM_RBUTTONUP:
			io.MouseDown[1] = false;
			return true;
		case WM_MBUTTONDOWN:
			io.MouseDown[2] = true;
			return true;
		case WM_MBUTTONUP:
			io.MouseDown[2] = false;
			return true;
		case WM_MOUSEWHEEL:
			io.MouseWheel += GET_WHEEL_DELTA_WPARAM(wParam) > 0 ? +1.0f : -1.0f;
			return true;
		case WM_MOUSEMOVE:
			io.MousePos.x = (signed short)(lParam);
			io.MousePos.y = (signed short)(lParam >> 16);
			return true;
		case WM_KEYDOWN:
			if (wParam < 256) io.KeysDown[wParam] = 1;
			return true;
		case WM_KEYUP:
			if (wParam < 256) io.KeysDown[wParam] = 0;
			return true;
		case WM_CHAR:
			if (wParam > 0 && wParam < 0x10000) io.AddInputCharacter((unsigned short)wParam);
			return true;
		}
		return false;

		//return UI::WndProcHandle(hWnd, uMsg, wParam, lParam);
	}
	void Init(HWND hwnd, IDirect3DDevice9* device)
	{
		cfg_manager->setup_item(&UI::Tabs::m_bShortMode, false, crypt_str("Menu.menu_short_mode"));

		cfg_manager->setup_item((int*)&UI::Colors::m_iText, IM_COL32(255, 255, 255, 255), crypt_str("Menu.menu_text_col"));
		cfg_manager->setup_item((int*)&UI::Colors::m_iTextAlt, IM_COL32(200, 200, 200, 255), crypt_str("Menu.menu_text_alt_col"));
		cfg_manager->setup_item((int*)&UI::Colors::m_iMenuBG, IM_COL32(24, 24, 24, 40), crypt_str("Menu.menu_bg"));
		cfg_manager->setup_item((int*)&UI::Colors::m_iMenuLeftBG, IM_COL32(36, 36, 36, 120), crypt_str("Menu.menu_leftbg"));
		cfg_manager->setup_item((int*)&UI::Colors::m_iMenuAltBG, IM_COL32(36, 36, 36, 30), crypt_str("Menu.menu_altbg"));
		cfg_manager->setup_item((int*)&UI::Colors::m_iPopupBG, IM_COL32(45, 45, 45, 255), crypt_str("Menu.menu_popupbg"));
		cfg_manager->setup_item((int*)&UI::Colors::m_iItem0, IM_COL32(123, 123, 123, 125), crypt_str("Menu.menu_itemcol"));

		UI::Init(hwnd, device);

		UI::Tabs::Add("Rage", '1');
		UI::Tabs::Add("Anti-Aim", '2');
		UI::Tabs::Add("Legit", '0');
		UI::Tabs::Add("Skins", '5');
		UI::Tabs::Add("Players", '7'); //weapons + world + grenades + view
		UI::Tabs::Add("Visuals", '3');
		UI::Tabs::Add("Misc", '6');
		UI::Tabs::Add("Scripts", '4');
		UI::Tabs::Add("Script Items", '4');
		UI::Tabs::Add("Config", '4');
	}
	void NewFrame()
	{
		UI::NewFrame();
	}
	void EndFrame()
	{
		UI::EndFrame();
	}

	float Get_MinX()
	{
		return UI::Window::m_iRect.Min.x;
	}
	float Get_MinY()
	{
		return UI::Window::m_iRect.Min.y;
	}
	float Get_MaxX()
	{
		return UI::Window::m_iRect.Max.x;
	}
	float Get_MaxY()
	{
		return UI::Window::m_iRect.Max.y;
	}

}