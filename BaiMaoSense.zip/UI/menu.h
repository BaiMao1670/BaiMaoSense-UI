#pragma once
#include <Windows.h>
#include <d3d9.h>


namespace Menu
{
	LRESULT WndProcHandle(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	void Init(HWND hwnd, IDirect3DDevice9* device);
	void NewFrame();
	void EndFrame();

	void Indicators();
	void Draw(bool menu_opened);

	float Get_MinX();
	float Get_MinY();
	float Get_MaxX();
	float Get_MaxY();
}